# RemediationFields

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**RemSource** | **string** | The origin of the content on which the remediated file was based. | [optional] [default to null]
**RemMetadataSource** | **[]string** | List of the origins of the metadata for the original creative work on which the remediated file was based. | [optional] [default to null]
**RemRemediatedBy** | **[]string** | List of the the origins of the remediated file, normally identifies the DSO. | [optional] [default to null]
**RemComplete** | **bool** | True if the submission is a presentation of the entire original work; false if the submission only covers certain sections or chapters, or contains gaps or omissions. | [optional] [default to null]
**RemCoverage** | **string** | For a submission which does not present the entire original work, describe the part(s) which are covered by the submission. | [optional] [default to null]
**RemRemediatedAspects** | **[]string** | List of the remediations that are provided in this submission. | [optional] [default to null]
**RemTextQuality** | **string** | A measure of the quality of the original file on which the submission was based.   * &#x60;rawOcr&#x60; - Raw OCR; scanned with OCR but not otherwise processed   * &#x60;cleanedOcr&#x60; - Cleaned OCR   * &#x60;rekeyed&#x60; - Rekeyed   * &#x60;proofread&#x60; - Proofread   * &#x60;published&#x60; - Received in an electronic format from the publisher  | [optional] [default to null]
**RemStatus** | **string** | The remediation status of submitted file. | [optional] [default to null]
**RemRemediationDate** | **string** | Date that this work was remediated.  This is an [ISO-8601](https://www.iso.org/iso-8601-date-and-time-format.html) format (YYYY-MM-DD) date. | [optional] [default to null]
**RemComments** | **string** | Comments regarding the remediation on this work | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

