'use strict';

var utils = require('../utils/writer.js');
var Ingestion = require('../service/IngestionService');

module.exports.deleteRecords = function deleteRecords (req, res, next, body) {
  Ingestion.deleteRecords(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.getRecords = function getRecords (req, res, next, body) {
  Ingestion.getRecords(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.upsertRecords = function upsertRecords (req, res, next, body) {
  Ingestion.upsertRecords(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
