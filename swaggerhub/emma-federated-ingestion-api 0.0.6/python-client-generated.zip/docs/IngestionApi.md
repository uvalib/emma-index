# swagger_client.IngestionApi

All URIs are relative to */*

Method | HTTP request | Description
------------- | ------------- | -------------
[**delete_records**](IngestionApi.md#delete_records) | **POST** /recordDeletes | Deletes metadata records in the search index
[**get_records**](IngestionApi.md#get_records) | **POST** /recordGets | Retrieves metadata records in the search index
[**upsert_records**](IngestionApi.md#upsert_records) | **PUT** /records | Inserts or updates metadata records in the search index

# **delete_records**
> dict(str, list[str]) delete_records(body=body)

Deletes metadata records in the search index

Deletes one or more metadataRecords in the search index. Records are uniquely identified by the emma_repository, emma_repositoryRecordId, dc_format, and emma_formatVersion.  emma_formatVersion is optional.   The number of records to be deleted at once is capped at 1000.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.IngestionApi()
body = [swagger_client.IdentifierRecord()] # list[IdentifierRecord] | Metadata identifier record (optional)

try:
    # Deletes metadata records in the search index
    api_response = api_instance.delete_records(body=body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling IngestionApi->delete_records: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**list[IdentifierRecord]**](IdentifierRecord.md)| Metadata identifier record | [optional] 

### Return type

**dict(str, list[str])**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_records**
> list[MetadataRecord] get_records(body=body)

Retrieves metadata records in the search index

Retrieves one or more metadataRecords in the search index. Records are uniquely identified by the emma_repository, emma_repositoryRecordId, dc_format, and emma_formatVersion.  emma_formatVersion is optional.  The number of records to be retrieved at once is capped at 1000.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.IngestionApi()
body = [swagger_client.IdentifierRecord()] # list[IdentifierRecord] | Metadata identifier record (optional)

try:
    # Retrieves metadata records in the search index
    api_response = api_instance.get_records(body=body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling IngestionApi->get_records: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**list[IdentifierRecord]**](IdentifierRecord.md)| Metadata identifier record | [optional] 

### Return type

[**list[MetadataRecord]**](MetadataRecord.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **upsert_records**
> upsert_records(body=body)

Inserts or updates metadata records in the search index

Inserts, or updates one or more metadataRecords in the search index.  For the upsert operation, if no such record exists for the emma_repository, emma_repositoryRecordId, dc_format, and emma_formatVersion, a record is created.  Otherwise the existing record is updated. emma_formatVersion is optional.  The number of records to be updated at once is capped at 1000.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.IngestionApi()
body = [swagger_client.IngestionRecord()] # list[IngestionRecord] | Ingestion metadata record (optional)

try:
    # Inserts or updates metadata records in the search index
    api_instance.upsert_records(body=body)
except ApiException as e:
    print("Exception when calling IngestionApi->upsert_records: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**list[IngestionRecord]**](IngestionRecord.md)| Ingestion metadata record | [optional] 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

