# EmmaFederatedIndexIngestionApi.IdentifierRecordList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
