# EmmaFederatedIndexIngestionApi.IdentifierRecord

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
