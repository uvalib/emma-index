# EmmaFederatedIndexIngestionApi.PeriodicalFields

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**periodical** | **Boolean** | True if we should treat this work like an article, issue, or episode of a periodical; False or absent otherwise.  | [optional] 
