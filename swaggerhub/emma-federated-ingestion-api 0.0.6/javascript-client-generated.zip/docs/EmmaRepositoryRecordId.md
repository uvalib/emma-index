# EmmaFederatedIndexIngestionApi.EmmaRepositoryRecordId

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
