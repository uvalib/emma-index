# EmmaFederatedIndexIngestionApi.IngestionRecordList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
