# EmmaFederatedIndexIngestionApi.EmmaRecordIdentifier

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
