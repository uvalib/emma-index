import connexion
import six

from swagger_server.models.identifier_record import IdentifierRecord  # noqa: E501
from swagger_server.models.ingestion_record import IngestionRecord  # noqa: E501
from swagger_server.models.metadata_record import MetadataRecord  # noqa: E501
from swagger_server import util


def delete_records(body=None):  # noqa: E501
    """Deletes metadata records in the search index

    Deletes one or more metadataRecords in the search index. Records are uniquely identified by the emma_repository, emma_repositoryRecordId, dc_format, and emma_formatVersion.  emma_formatVersion is optional.   The number of records to be deleted at once is capped at 1000. # noqa: E501

    :param body: Metadata identifier record
    :type body: list | bytes

    :rtype: Dict[str, List[str]]
    """
    if connexion.request.is_json:
        body = [IdentifierRecord.from_dict(d) for d in connexion.request.get_json()]  # noqa: E501
    return 'do some magic!'


def get_records(body=None):  # noqa: E501
    """Retrieves metadata records in the search index

    Retrieves one or more metadataRecords in the search index. Records are uniquely identified by the emma_repository, emma_repositoryRecordId, dc_format, and emma_formatVersion.  emma_formatVersion is optional.  The number of records to be retrieved at once is capped at 1000. # noqa: E501

    :param body: Metadata identifier record
    :type body: list | bytes

    :rtype: List[MetadataRecord]
    """
    if connexion.request.is_json:
        body = [IdentifierRecord.from_dict(d) for d in connexion.request.get_json()]  # noqa: E501
    return 'do some magic!'


def upsert_records(body=None):  # noqa: E501
    """Inserts or updates metadata records in the search index

    Inserts, or updates one or more metadataRecords in the search index.  For the upsert operation, if no such record exists for the emma_repository, emma_repositoryRecordId, dc_format, and emma_formatVersion, a record is created.  Otherwise the existing record is updated. emma_formatVersion is optional.  The number of records to be updated at once is capped at 1000. # noqa: E501

    :param body: Ingestion metadata record
    :type body: list | bytes

    :rtype: None
    """
    if connexion.request.is_json:
        body = [IngestionRecord.from_dict(d) for d in connexion.request.get_json()]  # noqa: E501
    return 'do some magic!'
