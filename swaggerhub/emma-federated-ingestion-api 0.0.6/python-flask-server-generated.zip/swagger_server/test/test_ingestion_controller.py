# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.models.identifier_record import IdentifierRecord  # noqa: E501
from swagger_server.models.ingestion_record import IngestionRecord  # noqa: E501
from swagger_server.models.metadata_record import MetadataRecord  # noqa: E501
from swagger_server.test import BaseTestCase


class TestIngestionController(BaseTestCase):
    """IngestionController integration test stubs"""

    def test_delete_records(self):
        """Test case for delete_records

        Deletes metadata records in the search index
        """
        body = [IdentifierRecord()]
        response = self.client.open(
            '/recordDeletes',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_records(self):
        """Test case for get_records

        Retrieves metadata records in the search index
        """
        body = [IdentifierRecord()]
        response = self.client.open(
            '/recordGets',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_upsert_records(self):
        """Test case for upsert_records

        Inserts or updates metadata records in the search index
        """
        body = [IngestionRecord()]
        response = self.client.open(
            '/records',
            method='PUT',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
