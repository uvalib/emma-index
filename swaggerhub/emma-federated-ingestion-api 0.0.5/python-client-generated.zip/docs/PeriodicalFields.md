# PeriodicalFields

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**periodical** | **bool** | True if we should treat this work like an article, issue, or episode of a periodical; False or absent otherwise.  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

