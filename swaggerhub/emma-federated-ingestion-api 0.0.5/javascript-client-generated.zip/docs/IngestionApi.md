# EmmaFederatedIndexIngestionApi.IngestionApi

All URIs are relative to */*

Method | HTTP request | Description
------------- | ------------- | -------------
[**deleteRecords**](IngestionApi.md#deleteRecords) | **POST** /recordDeletes | Deletes metadata records in the search index
[**getRecords**](IngestionApi.md#getRecords) | **POST** /recordGets | Retrieves metadata records in the search index
[**upsertRecords**](IngestionApi.md#upsertRecords) | **PUT** /records | Inserts or updates metadata records in the search index

<a name="deleteRecords"></a>
# **deleteRecords**
> {&#x27;String&#x27;: [&#x27;String&#x27;]} deleteRecords(opts)

Deletes metadata records in the search index

Deletes one or more metadataRecords in the search index. Records are uniquely identified by the emma_repository, emma_repositoryRecordId, dc_format, and emma_formatVersion.  emma_formatVersion is optional.   The number of records to be deleted at once is capped at 1000.

### Example
```javascript
import {EmmaFederatedIndexIngestionApi} from 'emma_federated_index_ingestion_api';

let apiInstance = new EmmaFederatedIndexIngestionApi.IngestionApi();
let opts = { 
  'body': [new EmmaFederatedIndexIngestionApi.IdentifierRecord()] // [IdentifierRecord] | Metadata identifier record
};
apiInstance.deleteRecords(opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**[IdentifierRecord]**](IdentifierRecord.md)| Metadata identifier record | [optional] 

### Return type

**{&#x27;String&#x27;: [&#x27;String&#x27;]}**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="getRecords"></a>
# **getRecords**
> [MetadataRecord] getRecords(opts)

Retrieves metadata records in the search index

Retrieves one or more metadataRecords in the search index. Records are uniquely identified by the emma_repository, emma_repositoryRecordId, dc_format, and emma_formatVersion.  emma_formatVersion is optional.  The number of records to be retrieved at once is capped at 1000.

### Example
```javascript
import {EmmaFederatedIndexIngestionApi} from 'emma_federated_index_ingestion_api';

let apiInstance = new EmmaFederatedIndexIngestionApi.IngestionApi();
let opts = { 
  'body': [new EmmaFederatedIndexIngestionApi.IdentifierRecord()] // [IdentifierRecord] | Metadata identifier record
};
apiInstance.getRecords(opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**[IdentifierRecord]**](IdentifierRecord.md)| Metadata identifier record | [optional] 

### Return type

[**[MetadataRecord]**](MetadataRecord.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="upsertRecords"></a>
# **upsertRecords**
> upsertRecords(opts)

Inserts or updates metadata records in the search index

Inserts, or updates one or more metadataRecords in the search index.  For the upsert operation, if no such record exists for the emma_repository, emma_repositoryRecordId, dc_format, and emma_formatVersion, a record is created.  Otherwise the existing record is updated. emma_formatVersion is optional.  The number of records to be updated at once is capped at 1000.

### Example
```javascript
import {EmmaFederatedIndexIngestionApi} from 'emma_federated_index_ingestion_api';

let apiInstance = new EmmaFederatedIndexIngestionApi.IngestionApi();
let opts = { 
  'body': [new EmmaFederatedIndexIngestionApi.IngestionRecord()] // [IngestionRecord] | Ingestion metadata record
};
apiInstance.upsertRecords(opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**[IngestionRecord]**](IngestionRecord.md)| Ingestion metadata record | [optional] 

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

