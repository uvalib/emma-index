# EmmaFederatedIndexIngestionApi.IngestionRecord

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
