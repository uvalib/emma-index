# EmmaFederatedIndexIngestionApi.MetadataRecord

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**dcTitle** | **String** | The [title](https://www.dublincore.org/specifications/dublin-core/dcmi-terms/terms/title/) of the work.  Refers to either a non-periodical work such as a book or movie, or the title of a work within a periodical, such as an article or episode.  Examples:   - Book:      - &#x60;The Catcher in the Rye&#x60;      - A book   - Movie:      - &#x60;Jaws&#x60;      - A movie   - Journal Article:      - &#x60;A Review of Discourse Markers from the Functional Perspective&#x60;      - Title of a an article appearing in the _Journal of Arts and Humanities_   - Podcast Episode:      - &#x60;741: The Weight of Words&#x60;      - Title of an episode in the podcast _This American Life_  | [optional] 
**dcCreator** | **[String]** | List of [creators](https://www.dublincore.org/specifications/dublin-core/dcmi-terms/terms/creator/) of the work | [optional] 
**dcIdentifier** | [**[PublicationIdentifier]**](PublicationIdentifier.md) | List of standard [identifier](https://www.dublincore.org/specifications/dublin-core/dcmi-terms/terms/identifier/) for a work.  In the case of | [optional] 
**dcPublisher** | **String** | The name of the [publisher](https://www.dublincore.org/specifications/dublin-core/dcmi-terms/terms/publisher/) | [optional] 
**dcRelation** | [**[PublicationIdentifier]**](PublicationIdentifier.md) | List of standard [identifiers](https://www.dublincore.org/specifications/dublin-core/dcmi-terms/terms/relation/) for related works | [optional] 
**dcLanguage** | **[String]** |  | [optional] 
**dcRights** | **String** | Ownership-based [usage rights](https://www.dublincore.org/specifications/dublin-core/dcmi-terms/terms/rights/) on the work.  [See the Creative Commons site for descriptions of the specifics of different Creative Commons licenses.](https://creativecommons.org/about/cclicenses/) The generic &#x60;creativeCommons&#x60; value is [DEPRECATED]. | [optional] 
**dcDescription** | **String** | [Description](https://www.dublincore.org/specifications/dublin-cor\\ e/dcmi-terms/terms/description/) of the work; typically a synopsis  | [optional] 
**dcFormat** | [**DublinCoreFormat**](DublinCoreFormat.md) |  | [optional] 
**dcType** | **String** | [DEPRECATED] [Type](https://www.dublincore.org/specifications/dublin-core/dcmi-\\ terms/terms/type/) of this instance of the work Use &#x60;emma_workType&#x60; instead.  | [optional] 
**dcSubject** | **[String]** | List of [subjects](https://www.dublincore.org/specifications/dublin-core/dcmi-terms/terms/subject/) describing the work. | [optional] 
**dctermsDateAccepted** | **Date** | [Date](https://www.dublincore.org/specifications/dublin-core/dcmi-terms/terms/dateAccepted/) that the work was accepted into the repository, using [ISO-8601](https://www.iso.org/iso-8601-date-and-time-format.html) format (YYYY-MM-DD) | [optional] 
**dctermsDateCopyright** | **String** | [DEPRECATED] The 4-digit year that the work was copyrighted Use &#x60;emma_publicationDate&#x60; instead.  | [optional] 
**periodical** | **Boolean** | True if we should treat this work like an article, issue, or episode of a periodical; False or absent otherwise.  | [optional] 
**sAccessibilityFeature** | **[String]** | List of accessibility features of this instance derived from the schema.org [Accessibility Feature specification](https://www.w3.org/wiki/WebSchemas/Accessibility#Accessibility_terms_.28Version_2.0.29). | [optional] 
**sAccessibilityControl** | **[String]** | List of accessibility controls of this instance derived from to the schema.org [Accessibility Control specification](https://www.w3.org/wiki/WebSchemas/Accessibility#Accessibility_terms_.28Version_2.0.29). | [optional] 
**sAccessibilityHazard** | **[String]** | List of accessibility hazards of this instance as derived from to the schema.org [Accessibility Hazard specification](https://www.w3.org/wiki/WebSchemas/Accessibility#Accessibility_terms_.28Version_2.0.29). | [optional] 
**sAccessibilityAPI** | **[String]** | List of accessibility APIs of this instance as derived from to the schema.org [Accessibility API specification](https://www.w3.org/wiki/WebSchemas/Accessibility#Accessibility_terms_.28Version_2.0.29). | [optional] 
**sAccessibilitySummary** | **String** | Human-readable summary of accessibility features or deficiencies of this instance of the work as described in the schema.org [Accessibility Summary specification](https://www.w3.org/wiki/WebSchemas/Accessibility#Accessibility_terms_.28Version_2.0.29) | [optional] 
**sAccessMode** | **[String]** | How the user can perceive this instance of the work as described in the schema.org [Access Mode specification](https://www.w3.org/wiki/WebSchemas/Accessibility#Accessibility_terms_.28Version_2.0.29). | [optional] 
**sAccessModeSufficient** | **[String]** | A list of single or combined access modes that are sufficient to understand all the intellectual content of a resource as described in the schema.org [Access Mode Sufficient specification](https://www.w3.org/wiki/WebSchemas/Accessibility#Accessibility_terms_.28Version_2.0.29) | [optional] 
**remSource** | **String** | The origin of the content on which the remediated file was based. | [optional] 
**remMetadataSource** | **[String]** | List of the origins of the metadata for the original creative work on which the remediated file was based. | [optional] 
**remRemediatedBy** | **[String]** | List of the the origins of the remediated file, normally identifies the DSO. | [optional] 
**remComplete** | **Boolean** | True if the submission is a presentation of the entire original work; false if the submission only covers certain sections or chapters, or contains gaps or omissions. | [optional] 
**remCoverage** | **String** | For a submission which does not present the entire original work, describe the part(s) which are covered by the submission. | [optional] 
**remRemediatedAspects** | **[String]** | List of the remediations that are provided in this submission. | [optional] 
**remTextQuality** | **String** | A measure of the quality of the original file on which the submission was based.   * &#x60;rawOcr&#x60; - Raw OCR; scanned with OCR but not otherwise processed   * &#x60;cleanedOcr&#x60; - Cleaned OCR   * &#x60;rekeyed&#x60; - Rekeyed   * &#x60;proofread&#x60; - Proofread   * &#x60;published&#x60; - Received in an electronic format from the publisher  | [optional] 
**remStatus** | **String** | The remediation status of submitted file. | [optional] 
**remRemediationDate** | **Date** | Date that this work was remediated.  This is an [ISO-8601](https://www.iso.org/iso-8601-date-and-time-format.html) format (YYYY-MM-DD) date. | [optional] 
**remComments** | **String** | Comments regarding the remediation on this work | [optional] 

<a name="DcRightsEnum"></a>
## Enum: DcRightsEnum

* `publicDomain` (value: `"publicDomain"`)
* `creativeCommons` (value: `"creativeCommons"`)
* `ccBy` (value: `"ccBy"`)
* `ccBySa` (value: `"ccBySa"`)
* `ccByNa` (value: `"ccByNa"`)
* `ccByNcSa` (value: `"ccByNcSa"`)
* `ccByNd` (value: `"ccByNd"`)
* `cc0` (value: `"cc0"`)
* `copyright` (value: `"copyright"`)
* `embargo` (value: `"embargo"`)
* `license` (value: `"license"`)
* `other` (value: `"other"`)


<a name="DcTypeEnum"></a>
## Enum: DcTypeEnum

* `text` (value: `"text"`)
* `sound` (value: `"sound"`)
* `collection` (value: `"collection"`)
* `dataset` (value: `"dataset"`)
* `event` (value: `"event"`)
* `image` (value: `"image"`)
* `interactiveResource` (value: `"interactiveResource"`)
* `service` (value: `"service"`)
* `physicalObject` (value: `"physicalObject"`)
* `stillImage` (value: `"stillImage"`)
* `movingImage` (value: `"movingImage"`)


<a name="[SAccessibilityFeatureEnum]"></a>
## Enum: [SAccessibilityFeatureEnum]

* `alternativeText` (value: `"alternativeText"`)
* `annotations` (value: `"annotations"`)
* `audioDescription` (value: `"audioDescription"`)
* `bookmarks` (value: `"bookmarks"`)
* `braille` (value: `"braille"`)
* `captions` (value: `"captions"`)
* `chemML` (value: `"ChemML"`)
* `describedMath` (value: `"describedMath"`)
* `displayTransformability` (value: `"displayTransformability"`)
* `displayTransformabilitybackgroundColor` (value: `"displayTransformability/background-color"`)
* `displayTransformabilitycolor` (value: `"displayTransformability/color"`)
* `displayTransformabilityfontHeight` (value: `"displayTransformability/font-height"`)
* `displayTransformabilityfontSize` (value: `"displayTransformability/font-size"`)
* `displayTransformabilitylineHeight` (value: `"displayTransformability/line-height"`)
* `displayTransformabilitywordSpacing` (value: `"displayTransformability/word-spacing"`)
* `highContrastAudio` (value: `"highContrastAudio"`)
* `highContrastDisplay` (value: `"highContrastDisplay"`)
* `index` (value: `"index"`)
* `largePrint` (value: `"largePrint"`)
* `latex` (value: `"latex"`)
* `longDescription` (value: `"longDescription"`)
* `mathML` (value: `"MathML"`)
* `physicalObject` (value: `"physicalObject"`)
* `printPageNumbers` (value: `"printPageNumbers"`)
* `readingOrder` (value: `"readingOrder"`)
* `rubyAnnotations` (value: `"rubyAnnotations"`)
* `signLanguage` (value: `"signLanguage"`)
* `sound` (value: `"sound"`)
* `stillImage` (value: `"stillImage"`)
* `structuralNavigation` (value: `"structuralNavigation"`)
* `synchronizedAudioText` (value: `"synchronizedAudioText"`)
* `tableOfContents` (value: `"tableOfContents"`)
* `tactileGraphic` (value: `"tactileGraphic"`)
* `tactileObject` (value: `"tactileObject"`)
* `taggedPDF` (value: `"taggedPDF"`)
* `timingControl` (value: `"timingControl"`)
* `transcript` (value: `"transcript"`)
* `ttsMarkup` (value: `"ttsMarkup"`)
* `unlocked` (value: `"unlocked"`)


<a name="[SAccessibilityControlEnum]"></a>
## Enum: [SAccessibilityControlEnum]

* `fullAudioControl` (value: `"fullAudioControl"`)
* `fullKeyboardControl` (value: `"fullKeyboardControl"`)
* `fullMouseControl` (value: `"fullMouseControl"`)
* `fullTouchControl` (value: `"fullTouchControl"`)
* `fullVideoControl` (value: `"fullVideoControl"`)
* `fullSwitchControl` (value: `"fullSwitchControl"`)
* `fullVoiceControl` (value: `"fullVoiceControl"`)


<a name="[SAccessibilityHazardEnum]"></a>
## Enum: [SAccessibilityHazardEnum]

* `flashing` (value: `"flashing"`)
* `noFlashingHazard` (value: `"noFlashingHazard"`)
* `motionSimulation` (value: `"motionSimulation"`)
* `noMotionSimulationHazard` (value: `"noMotionSimulationHazard"`)
* `sound` (value: `"sound"`)
* `noSoundHazard` (value: `"noSoundHazard"`)


<a name="[SAccessibilityAPIEnum]"></a>
## Enum: [SAccessibilityAPIEnum]

* `ARIA` (value: `"ARIA"`)


<a name="[SAccessModeEnum]"></a>
## Enum: [SAccessModeEnum]

* `auditory` (value: `"auditory"`)
* `chartOnVisual` (value: `"chartOnVisual"`)
* `chemOnVisual` (value: `"chemOnVisual"`)
* `colorDependent` (value: `"colorDependent"`)
* `diagramOnVisual` (value: `"diagramOnVisual"`)
* `mathOnVisual` (value: `"mathOnVisual"`)
* `musicOnVisual` (value: `"musicOnVisual"`)
* `tactile` (value: `"tactile"`)
* `textOnVisual` (value: `"textOnVisual"`)
* `textual` (value: `"textual"`)
* `visual` (value: `"visual"`)


<a name="[SAccessModeSufficientEnum]"></a>
## Enum: [SAccessModeSufficientEnum]

* `auditory` (value: `"auditory"`)
* `tactile` (value: `"tactile"`)
* `textual` (value: `"textual"`)
* `visual` (value: `"visual"`)


<a name="RemSourceEnum"></a>
## Enum: RemSourceEnum

* `bookshare` (value: `"bookshare"`)
* `hathiTrust` (value: `"hathiTrust"`)
* `internetArchive` (value: `"internetArchive"`)
* `emma` (value: `"emma"`)
* `accessTextNetwork` (value: `"accessTextNetwork"`)
* `publisher` (value: `"publisher"`)
* `purchased` (value: `"purchased"`)
* `faculty` (value: `"faculty"`)
* `student` (value: `"student"`)
* `library` (value: `"library"`)
* `otherDso` (value: `"otherDso"`)
* `other` (value: `"other"`)


<a name="[RemRemediatedAspectsEnum]"></a>
## Enum: [RemRemediatedAspectsEnum]

* `scannedAndOcrd` (value: `"scannedAndOcrd"`)
* `proofreadCorrectedOcr` (value: `"proofreadCorrectedOcr"`)
* `addedBookmarks` (value: `"addedBookmarks"`)
* `taggedPdf` (value: `"taggedPdf"`)
* `addedImageDescriptions` (value: `"addedImageDescriptions"`)
* `structuredHeadings` (value: `"structuredHeadings"`)
* `linkedToc` (value: `"linkedToc"`)
* `fixedTables` (value: `"fixedTables"`)
* `addedMathMl` (value: `"addedMathMl"`)
* `foreignLanguageMarkup` (value: `"foreignLanguageMarkup"`)
* `transcribersNotes` (value: `"transcribersNotes"`)
* `annotations` (value: `"annotations"`)


<a name="RemTextQualityEnum"></a>
## Enum: RemTextQualityEnum

* `rawOcr` (value: `"rawOcr"`)
* `cleanedOcr` (value: `"cleanedOcr"`)
* `rekeyed` (value: `"rekeyed"`)
* `proofread` (value: `"proofread"`)
* `published` (value: `"published"`)


<a name="RemStatusEnum"></a>
## Enum: RemStatusEnum

* `remediated` (value: `"remediated"`)
* `notRemediated` (value: `"notRemediated"`)
* `bornAccessible` (value: `"bornAccessible"`)

