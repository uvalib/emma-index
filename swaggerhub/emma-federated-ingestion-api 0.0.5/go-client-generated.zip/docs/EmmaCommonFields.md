# EmmaCommonFields

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**EmmaRepository** | [***EmmaRepository**](EmmaRepository.md) |  | [optional] [default to null]
**EmmaCollection** | **[]string** | A set of works within a repository | [optional] [default to null]
**EmmaRepositoryRecordId** | **string** |  | [optional] [default to null]
**EmmaRetrievalLink** | **string** | Link to download an actual work from a repository | [optional] [default to null]
**EmmaWebPageLink** | **string** | Link to a web page which describes a work from a repository | [optional] [default to null]
**EmmaLastRemediationDate** | **string** | [DEPRECATED] Date that this work was remediated.  Use &#x60;rem_remediationDate&#x60; instead.  | [optional] [default to null]
**EmmaLastRemediationNote** | **string** | [DEPRECATED] Comments regarding the remediation on this work.  Use &#x60;rem_comments&#x60; instead.  | [optional] [default to null]
**EmmaSortDate** | **string** | Last date that the work or this index was updated, guaranteeing a non-null value. If available, this defaults to the same value as last remediation date.  If not available, it defaults to date accepted.  If date accepted is not available, it defaults to the date that the record was last updated in this index. The value of sort date is determined at indexing time, and does not need to be sent through the ingestion API. | [optional] [default to null]
**EmmaRepositoryUpdateDate** | **string** | Date that this metadata was last updated in the source repository | [optional] [default to null]
**EmmaRepositoryMetadataUpdateDate** | **string** | [DEPRECATED] Use &#x60;emma_repositoryUpdateDate&#x60; instead. Date that this metadata was last updated in the source repository  | [optional] [default to null]
**EmmaPublicationDate** | **string** | The date that this work was published.  This is an [ISO-8601](https://www.iso.org/iso-8601-date-and-time-format.html) format (YYYY-MM-DD) date or a 4-digit year.  | [optional] [default to null]
**EmmaVersion** | **string** | Denotes a version or edition for a non-periodical work or a single issue or episode.  Examples: - &#x60;Student Edition&#x60; - &#x60;2e&#x60; - &#x60;InitialPub&#x60; - &#x60;Corrected&#x60; - &#x60;Augmented&#x60;  | [optional] [default to null]
**EmmaWorkType** | **string** | Describes the type of work.  | [optional] [default to null]
**EmmaFormatVersion** | **string** |  | [optional] [default to null]
**EmmaFormatFeature** | **[]string** | List of features of the format used by this instance of this work * &#x60;tts&#x60; - Audio generated via Text-to-Speech * &#x60;human&#x60; - Audio read by a human * &#x60;grade1&#x60; - Grade 1 (contracted) Braille * &#x60;grade2&#x60; - Grade 2 (uncontracted) Braille * &#x60;nemeth&#x60; - Nemeth Braille Code for Mathematics and Science Notation * &#x60;ueb&#x60; - Unified English Braille * &#x60;ebae&#x60; - English Braille American Edition (Literary Code) * &#x60;music&#x60; - Music Braille Code.  Could also describe a music subtype of another dc_format. * &#x60;imagePdf&#x60; - PDF that has been scanned as images with no differentiated text * &#x60;digitalTextPdf&#x60; - PDF that contains digital text * &#x60;literary&#x60; - [DEPRECATED] Use &#x60;ebae&#x60;. * &#x60;technical&#x60; - [DEPRECATED] use &#x60;ueb&#x60; and/or &#x60;nemeth&#x60; as applicable.  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

