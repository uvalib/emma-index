# SchemaOrgFields

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**SAccessibilityFeature** | **[]string** | List of accessibility features of this instance derived from the schema.org [Accessibility Feature specification](https://www.w3.org/wiki/WebSchemas/Accessibility#Accessibility_terms_.28Version_2.0.29). | [optional] [default to null]
**SAccessibilityControl** | **[]string** | List of accessibility controls of this instance derived from to the schema.org [Accessibility Control specification](https://www.w3.org/wiki/WebSchemas/Accessibility#Accessibility_terms_.28Version_2.0.29). | [optional] [default to null]
**SAccessibilityHazard** | **[]string** | List of accessibility hazards of this instance as derived from to the schema.org [Accessibility Hazard specification](https://www.w3.org/wiki/WebSchemas/Accessibility#Accessibility_terms_.28Version_2.0.29). | [optional] [default to null]
**SAccessibilityAPI** | **[]string** | List of accessibility APIs of this instance as derived from to the schema.org [Accessibility API specification](https://www.w3.org/wiki/WebSchemas/Accessibility#Accessibility_terms_.28Version_2.0.29). | [optional] [default to null]
**SAccessibilitySummary** | **string** | Human-readable summary of accessibility features or deficiencies of this instance of the work as described in the schema.org [Accessibility Summary specification](https://www.w3.org/wiki/WebSchemas/Accessibility#Accessibility_terms_.28Version_2.0.29) | [optional] [default to null]
**SAccessMode** | **[]string** | How the user can perceive this instance of the work as described in the schema.org [Access Mode specification](https://www.w3.org/wiki/WebSchemas/Accessibility#Accessibility_terms_.28Version_2.0.29). | [optional] [default to null]
**SAccessModeSufficient** | **[]string** | A list of single or combined access modes that are sufficient to understand all the intellectual content of a resource as described in the schema.org [Access Mode Sufficient specification](https://www.w3.org/wiki/WebSchemas/Accessibility#Accessibility_terms_.28Version_2.0.29) | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

