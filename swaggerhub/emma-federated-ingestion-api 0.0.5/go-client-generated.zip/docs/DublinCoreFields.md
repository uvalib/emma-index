# DublinCoreFields

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**DcTitle** | **string** | The [title](https://www.dublincore.org/specifications/dublin-core/dcmi-terms/terms/title/) of the work.  Refers to either a non-periodical work such as a book or movie, or the title of a work within a periodical, such as an article or episode.  Examples:   - Book:      - &#x60;The Catcher in the Rye&#x60;      - A book   - Movie:      - &#x60;Jaws&#x60;      - A movie   - Journal Article:      - &#x60;A Review of Discourse Markers from the Functional Perspective&#x60;      - Title of a an article appearing in the _Journal of Arts and Humanities_   - Podcast Episode:      - &#x60;741: The Weight of Words&#x60;      - Title of an episode in the podcast _This American Life_  | [optional] [default to null]
**DcCreator** | **[]string** | List of [creators](https://www.dublincore.org/specifications/dublin-core/dcmi-terms/terms/creator/) of the work | [optional] [default to null]
**DcIdentifier** | **[]string** | List of standard [identifier](https://www.dublincore.org/specifications/dublin-core/dcmi-terms/terms/identifier/) for a work.  In the case of | [optional] [default to null]
**DcPublisher** | **string** | The name of the [publisher](https://www.dublincore.org/specifications/dublin-core/dcmi-terms/terms/publisher/) | [optional] [default to null]
**DcRelation** | **[]string** | List of standard [identifiers](https://www.dublincore.org/specifications/dublin-core/dcmi-terms/terms/relation/) for related works | [optional] [default to null]
**DcLanguage** | **[]string** |  | [optional] [default to null]
**DcRights** | **string** | Ownership-based [usage rights](https://www.dublincore.org/specifications/dublin-core/dcmi-terms/terms/rights/) on the work.  [See the Creative Commons site for descriptions of the specifics of different Creative Commons licenses.](https://creativecommons.org/about/cclicenses/) The generic &#x60;creativeCommons&#x60; value is [DEPRECATED]. | [optional] [default to null]
**DcDescription** | **string** | [Description](https://www.dublincore.org/specifications/dublin-cor\\ e/dcmi-terms/terms/description/) of the work; typically a synopsis  | [optional] [default to null]
**DcFormat** | [***DublinCoreFormat**](DublinCoreFormat.md) |  | [optional] [default to null]
**DcType** | **string** | [DEPRECATED] [Type](https://www.dublincore.org/specifications/dublin-core/dcmi-\\ terms/terms/type/) of this instance of the work Use &#x60;emma_workType&#x60; instead.  | [optional] [default to null]
**DcSubject** | **[]string** | List of [subjects](https://www.dublincore.org/specifications/dublin-core/dcmi-terms/terms/subject/) describing the work. | [optional] [default to null]
**DctermsDateAccepted** | **string** | [Date](https://www.dublincore.org/specifications/dublin-core/dcmi-terms/terms/dateAccepted/) that the work was accepted into the repository, using [ISO-8601](https://www.iso.org/iso-8601-date-and-time-format.html) format (YYYY-MM-DD) | [optional] [default to null]
**DctermsDateCopyright** | **string** | [DEPRECATED] The 4-digit year that the work was copyrighted Use &#x60;emma_publicationDate&#x60; instead.  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

