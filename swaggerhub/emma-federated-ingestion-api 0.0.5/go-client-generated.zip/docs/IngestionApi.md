# {{classname}}

All URIs are relative to */*

Method | HTTP request | Description
------------- | ------------- | -------------
[**DeleteRecords**](IngestionApi.md#DeleteRecords) | **Post** /recordDeletes | Deletes metadata records in the search index
[**GetRecords**](IngestionApi.md#GetRecords) | **Post** /recordGets | Retrieves metadata records in the search index
[**UpsertRecords**](IngestionApi.md#UpsertRecords) | **Put** /records | Inserts or updates metadata records in the search index

# **DeleteRecords**
> map[string][]string DeleteRecords(ctx, optional)
Deletes metadata records in the search index

Deletes one or more metadataRecords in the search index. Records are uniquely identified by the emma_repository, emma_repositoryRecordId, dc_format, and emma_formatVersion.  emma_formatVersion is optional.   The number of records to be deleted at once is capped at 1000.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
 **optional** | ***IngestionApiDeleteRecordsOpts** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a pointer to a IngestionApiDeleteRecordsOpts struct
Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**optional.Interface of []IdentifierRecord**](IdentifierRecord.md)| Metadata identifier record | 

### Return type

[**map[string][]string**](array.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **GetRecords**
> []MetadataRecord GetRecords(ctx, optional)
Retrieves metadata records in the search index

Retrieves one or more metadataRecords in the search index. Records are uniquely identified by the emma_repository, emma_repositoryRecordId, dc_format, and emma_formatVersion.  emma_formatVersion is optional.  The number of records to be retrieved at once is capped at 1000.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
 **optional** | ***IngestionApiGetRecordsOpts** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a pointer to a IngestionApiGetRecordsOpts struct
Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**optional.Interface of []IdentifierRecord**](IdentifierRecord.md)| Metadata identifier record | 

### Return type

[**[]MetadataRecord**](MetadataRecord.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **UpsertRecords**
> UpsertRecords(ctx, optional)
Inserts or updates metadata records in the search index

Inserts, or updates one or more metadataRecords in the search index.  For the upsert operation, if no such record exists for the emma_repository, emma_repositoryRecordId, dc_format, and emma_formatVersion, a record is created.  Otherwise the existing record is updated. emma_formatVersion is optional.  The number of records to be updated at once is capped at 1000.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
 **optional** | ***IngestionApiUpsertRecordsOpts** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a pointer to a IngestionApiUpsertRecordsOpts struct
Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**optional.Interface of []IngestionRecord**](IngestionRecord.md)| Ingestion metadata record | 

### Return type

 (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

