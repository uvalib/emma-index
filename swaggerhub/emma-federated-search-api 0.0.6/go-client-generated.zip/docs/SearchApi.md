# {{classname}}

All URIs are relative to *https://api.staging.bookshareunifiedsearch.org*

Method | HTTP request | Description
------------- | ------------- | -------------
[**SearchMetadata**](SearchApi.md#SearchMetadata) | **Get** /search | Search for metadata records

# **SearchMetadata**
> []MetadataRecord SearchMetadata(ctx, optional)
Search for metadata records

Search for metadata records against common fields.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
 **optional** | ***SearchApiSearchMetadataOpts** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a pointer to a SearchApiSearchMetadataOpts struct
Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **q** | **optional.String**| The string passed in will be searched against title, creator, and publication identifiers such as ISBN and OCLC number.  If the q parameter is specified, the title, creator, publisher, and identifier parameters are ignored. | 
 **creator** | **optional.String**| The string passed in will be searched against creators.  These will most commonly be authors, but may also include editors and other contributors. | 
 **title** | **optional.String**| The string passed in will be searched against result titles. | 
 **identifier** | **optional.String**| The string passed in will be searched against publication identifiers such as ISBN and OCLC number. | 
 **publisher** | **optional.String**| Search results will be limited to works with the given publisher. This currently does not work when combined with the q search parameter. | 
 **format** | [**optional.Interface of []Format**](Format.md)| Search results will be limited to works with the given formats. | 
 **formatFeature** | [**optional.Interface of []string**](.md)| Search results will be limited to works with the given format features. | 
 **formatVersion** | [**optional.Interface of string**](.md)| Search results will be limited to works with the given format version. | 
 **accessibilityFeature** | [**optional.Interface of []string**](.md)| Search results will be limited to works with the given [accessibility features](https://www.w3.org/wiki/WebSchemas/Accessibility#Accessibility_terms_.28Version_2.0.29). | 
 **repository** | [**optional.Interface of Repository**](.md)| Search results will be limited to works in the given repository. | 
 **collection** | [**optional.Interface of []string**](.md)| Search results will be limited to works in the given repository collection. | 
 **lastRemediationDate** | [**optional.Interface of string**](.md)| Search results will be limited to works with a remediation date after the given date. Format is [ISO-8601](https://www.iso.org/iso-8601-date-and-time-format.html) date format (YYYY-MM-DD) | 
 **publicationDate** | [**optional.Interface of string**](.md)| Search results will be limited to works with a publication date after the given date. Format is either a 4-digit year or the [ISO-8601](https://www.iso.org/iso-8601-date-and-time-format.html) date format (YYYY-MM-DD) | 
 **sortDate** | [**optional.Interface of string**](.md)| Search results will be limited to works with a sort date after the given date. Format is [ISO-8601](https://www.iso.org/iso-8601-date-and-time-format.html) date format (YYYY-MM-DD) Sort date defaults to the same value as last remediation date.  If not available, it defaults to date accepted.  If date accepted is not available, it defaults to the date that the record was last updated in this index.  This field is never expected to be null. | 
 **sort** | **optional.String**| Results will be sorted in the given order, with title order ascending and date order descending.  Last remediation date is likely to be null; sort date is guaranteed not to be null.  When not specified, sort defaults to relevance. | 
 **searchAfterId** | [**optional.Interface of string**](.md)| When paging through sorted results, return the next page of results that come after the record with this EMMA Record Identifier, i.e. the last emma_recordId in a previous page of results.  Must be paired with a searchAfterValue parameter.  When using the default relevance sort, use the \&quot;from\&quot; parameter instead for paging. | 
 **searchAfterValue** | [**optional.Interface of SearchAfterValue**](.md)| When paging through sorted results, return the next page of results that come after the record with this URL encoded title or last remediation date, i.e. the last dc_title, dc_sortDate, emma_publicationDate, or emma_lastRemediationDate in a previous page of results. This value must match the type of the search sort.  Must be paired with a searchAfterId parameter. If a title value is truncated, the search engine will make its best effort to find the record for determining the page break. When using the default relevance sort, use the \&quot;from\&quot; parameter instead for paging. | 
 **size** | **optional.Int32**| Number of results to return in the next page of results.   Defaults to 100. | 
 **from** | **optional.Int32**| When using the default relevance result sort, use \&quot;from\&quot; to return the next page of results starting from the given result number.  If results are sorted, use searchAfterId and searchAfterValue instead. A limit of 1000 total results can be retrieved for the current query using the \&quot;from\&quot; parameter. | 
 **group** | [**optional.Interface of []Group**](Group.md)| [EXPERIMENTAL] Search results will be grouped by the given field.  Result page size will automatically be limited to 10 maximum.  Each result will have a number of grouped records provided as children, so the number of records returned will be more than 10.  Cannot be combined with sorting by title or date.  | 

### Return type

[**[]MetadataRecord**](MetadataRecord.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

