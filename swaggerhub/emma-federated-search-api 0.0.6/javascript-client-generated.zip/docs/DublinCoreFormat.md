# EmmaFederatedSearchApi.DublinCoreFormat

## Enum

* `brf` (value: `"brf"`)
* `daisy` (value: `"daisy"`)
* `daisyAudio` (value: `"daisyAudio"`)
* `epub` (value: `"epub"`)
* `braille` (value: `"braille"`)
* `pdf` (value: `"pdf"`)
* `grayscalePdf` (value: `"grayscalePdf"`)
* `word` (value: `"word"`)
* `tactile` (value: `"tactile"`)
* `kurzweil` (value: `"kurzweil"`)
* `rtf` (value: `"rtf"`)
