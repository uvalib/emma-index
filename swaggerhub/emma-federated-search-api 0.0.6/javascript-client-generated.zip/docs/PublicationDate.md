# EmmaFederatedSearchApi.PublicationDate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
