# EmmaFederatedSearchApi.SAccessibilityFeature

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
