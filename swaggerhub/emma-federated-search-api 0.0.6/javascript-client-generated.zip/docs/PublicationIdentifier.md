# EmmaFederatedSearchApi.PublicationIdentifier

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
