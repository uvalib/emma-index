# EmmaFederatedSearchApi.RemediationFields

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**remSource** | **String** | The origin of the content on which the remediated file was based. | [optional] 
**remMetadataSource** | **[String]** | List of the origins of the metadata for the original creative work on which the remediated file was based. | [optional] 
**remRemediatedBy** | **[String]** | List of the the origins of the remediated file, normally identifies the DSO. | [optional] 
**remComplete** | **Boolean** | True if the submission is a presentation of the entire original work; false if the submission only covers certain sections or chapters, or contains gaps or omissions. | [optional] 
**remCoverage** | **String** | For a submission which does not present the entire original work, describe the part(s) which are covered by the submission. | [optional] 
**remRemediatedAspects** | **[String]** | List of the remediations that are provided in this submission. | [optional] 
**remTextQuality** | **String** | A measure of the quality of the original file on which the submission was based.   * &#x60;rawOcr&#x60; - Raw OCR; scanned with OCR but not otherwise processed   * &#x60;cleanedOcr&#x60; - Cleaned OCR   * &#x60;rekeyed&#x60; - Rekeyed   * &#x60;proofread&#x60; - Proofread   * &#x60;published&#x60; - Received in an electronic format from the publisher  | [optional] 
**remStatus** | **String** | The remediation status of submitted file. | [optional] 
**remRemediationDate** | **Date** | Date that this work was remediated.  This is an [ISO-8601](https://www.iso.org/iso-8601-date-and-time-format.html) format (YYYY-MM-DD) date. | [optional] 
**remComments** | **String** | Comments regarding the remediation on this work | [optional] 

<a name="RemSourceEnum"></a>
## Enum: RemSourceEnum

* `bookshare` (value: `"bookshare"`)
* `hathiTrust` (value: `"hathiTrust"`)
* `internetArchive` (value: `"internetArchive"`)
* `emma` (value: `"emma"`)
* `accessTextNetwork` (value: `"accessTextNetwork"`)
* `publisher` (value: `"publisher"`)
* `purchased` (value: `"purchased"`)
* `faculty` (value: `"faculty"`)
* `student` (value: `"student"`)
* `library` (value: `"library"`)
* `otherDso` (value: `"otherDso"`)
* `other` (value: `"other"`)


<a name="[RemRemediatedAspectsEnum]"></a>
## Enum: [RemRemediatedAspectsEnum]

* `scannedAndOcrd` (value: `"scannedAndOcrd"`)
* `proofreadCorrectedOcr` (value: `"proofreadCorrectedOcr"`)
* `addedBookmarks` (value: `"addedBookmarks"`)
* `taggedPdf` (value: `"taggedPdf"`)
* `addedImageDescriptions` (value: `"addedImageDescriptions"`)
* `structuredHeadings` (value: `"structuredHeadings"`)
* `linkedToc` (value: `"linkedToc"`)
* `fixedTables` (value: `"fixedTables"`)
* `addedMathMl` (value: `"addedMathMl"`)
* `foreignLanguageMarkup` (value: `"foreignLanguageMarkup"`)
* `transcribersNotes` (value: `"transcribersNotes"`)
* `annotations` (value: `"annotations"`)


<a name="RemTextQualityEnum"></a>
## Enum: RemTextQualityEnum

* `rawOcr` (value: `"rawOcr"`)
* `cleanedOcr` (value: `"cleanedOcr"`)
* `rekeyed` (value: `"rekeyed"`)
* `proofread` (value: `"proofread"`)
* `published` (value: `"published"`)


<a name="RemStatusEnum"></a>
## Enum: RemStatusEnum

* `remediated` (value: `"remediated"`)
* `notRemediated` (value: `"notRemediated"`)
* `bornAccessible` (value: `"bornAccessible"`)

