# EmmaFederatedSearchApi.EmmaCollection

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
