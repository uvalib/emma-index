# EmmaFederatedSearchApi.EmmaRepository

## Enum

* `bookshare` (value: `"bookshare"`)
* `hathiTrust` (value: `"hathiTrust"`)
* `internetArchive` (value: `"internetArchive"`)
* `emma` (value: `"emma"`)
* `ace` (value: `"ace"`)
