# EmmaFederatedSearchApi.SortDate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
