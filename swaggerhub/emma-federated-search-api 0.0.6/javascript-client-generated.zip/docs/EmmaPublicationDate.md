# EmmaFederatedSearchApi.EmmaPublicationDate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
