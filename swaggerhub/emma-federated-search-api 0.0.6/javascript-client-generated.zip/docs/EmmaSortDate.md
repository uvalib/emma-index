# EmmaFederatedSearchApi.EmmaSortDate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
