# EmmaFederatedSearchApi.EmmaRecordIdentifier

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
