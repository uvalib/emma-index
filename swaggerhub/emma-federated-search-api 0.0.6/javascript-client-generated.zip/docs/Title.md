# EmmaFederatedSearchApi.Title

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
