# EmmaFederatedSearchApi.EmmaFormatFeature

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
