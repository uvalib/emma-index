# EmmaFederatedSearchApi.AccessibilityFeature

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
