# EmmaFederatedSearchApi.EmmaRepositoryRecordId

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
