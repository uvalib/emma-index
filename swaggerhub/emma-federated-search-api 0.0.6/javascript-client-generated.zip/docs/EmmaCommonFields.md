# EmmaFederatedSearchApi.EmmaCommonFields

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**emmaRepository** | [**EmmaRepository**](EmmaRepository.md) |  | [optional] 
**emmaCollection** | **[String]** | A set of works within a repository | [optional] 
**emmaRepositoryRecordId** | [**EmmaRepositoryRecordId**](EmmaRepositoryRecordId.md) |  | [optional] 
**emmaRetrievalLink** | **String** | Link to download an actual work from a repository | [optional] 
**emmaWebPageLink** | **String** | Link to a web page which describes a work from a repository | [optional] 
**emmaLastRemediationDate** | **Date** | [DEPRECATED] Date that this work was remediated.  Use &#x60;rem_remediationDate&#x60; instead.  | [optional] 
**emmaLastRemediationNote** | **String** | [DEPRECATED] Comments regarding the remediation on this work.  Use &#x60;rem_comments&#x60; instead.  | [optional] 
**emmaSortDate** | **Date** | Last date that the work or this index was updated, guaranteeing a non-null value. If available, this defaults to the same value as last remediation date.  If not available, it defaults to date accepted.  If date accepted is not available, it defaults to the date that the record was last updated in this index. The value of sort date is determined at indexing time, and does not need to be sent through the ingestion API. | [optional] 
**emmaRepositoryUpdateDate** | **Date** | Date that this metadata was last updated in the source repository | [optional] 
**emmaRepositoryMetadataUpdateDate** | **Date** | [DEPRECATED] Use &#x60;emma_repositoryUpdateDate&#x60; instead. Date that this metadata was last updated in the source repository  | [optional] 
**emmaPublicationDate** | **Date** | The date that this work was published.  This is an [ISO-8601](https://www.iso.org/iso-8601-date-and-time-format.html) format (YYYY-MM-DD) date or a 4-digit year.  | [optional] 
**emmaVersion** | **String** | Denotes a version or edition for a non-periodical work or a single issue or episode.  Examples: - &#x60;Student Edition&#x60; - &#x60;2e&#x60; - &#x60;InitialPub&#x60; - &#x60;Corrected&#x60; - &#x60;Augmented&#x60;  | [optional] 
**emmaWorkType** | **String** | Describes the type of work.  | [optional] 
**emmaFormatVersion** | [**EmmaFormatVersion**](EmmaFormatVersion.md) |  | [optional] 
**emmaFormatFeature** | **[String]** | List of features of the format used by this instance of this work * &#x60;tts&#x60; - Audio generated via Text-to-Speech * &#x60;human&#x60; - Audio read by a human * &#x60;grade1&#x60; - Grade 1 (contracted) Braille * &#x60;grade2&#x60; - Grade 2 (uncontracted) Braille * &#x60;nemeth&#x60; - Nemeth Braille Code for Mathematics and Science Notation * &#x60;ueb&#x60; - Unified English Braille * &#x60;ebae&#x60; - English Braille American Edition (Literary Code) * &#x60;music&#x60; - Music Braille Code.  Could also describe a music subtype of another dc_format. * &#x60;imagePdf&#x60; - PDF that has been scanned as images with no differentiated text * &#x60;digitalTextPdf&#x60; - PDF that contains digital text * &#x60;literary&#x60; - [DEPRECATED] Use &#x60;ebae&#x60;. * &#x60;technical&#x60; - [DEPRECATED] use &#x60;ueb&#x60; and/or &#x60;nemeth&#x60; as applicable.  | [optional] 

<a name="EmmaWorkTypeEnum"></a>
## Enum: EmmaWorkTypeEnum

* `book` (value: `"book"`)
* `video` (value: `"video"`)
* `article` (value: `"article"`)
* `podcast` (value: `"podcast"`)


<a name="[EmmaFormatFeatureEnum]"></a>
## Enum: [EmmaFormatFeatureEnum]

* `tts` (value: `"tts"`)
* `human` (value: `"human"`)
* `grade1` (value: `"grade1"`)
* `grade2` (value: `"grade2"`)
* `nemeth` (value: `"nemeth"`)
* `ueb` (value: `"ueb"`)
* `ebae` (value: `"ebae"`)
* `music` (value: `"music"`)
* `imagePdf` (value: `"imagePdf"`)
* `digitalTextPdf` (value: `"digitalTextPdf"`)
* `literary` (value: `"literary"`)
* `technical` (value: `"technical"`)

