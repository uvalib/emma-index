import connexion
import six

from swagger_server.models.accessibility_feature import AccessibilityFeature  # noqa: E501
from swagger_server.models.collection import Collection  # noqa: E501
from swagger_server.models.emma_format_version import EmmaFormatVersion  # noqa: E501
from swagger_server.models.emma_record_identifier import EmmaRecordIdentifier  # noqa: E501
from swagger_server.models.format import Format  # noqa: E501
from swagger_server.models.format_feature import FormatFeature  # noqa: E501
from swagger_server.models.group import Group  # noqa: E501
from swagger_server.models.last_remediation_date import LastRemediationDate  # noqa: E501
from swagger_server.models.metadata_record import MetadataRecord  # noqa: E501
from swagger_server.models.publication_date import PublicationDate  # noqa: E501
from swagger_server.models.repository import Repository  # noqa: E501
from swagger_server.models.search_after_value import SearchAfterValue  # noqa: E501
from swagger_server.models.sort_date import SortDate  # noqa: E501
from swagger_server import util


def search_metadata(q=None, creator=None, title=None, identifier=None, publisher=None, format=None, format_feature=None, format_version=None, accessibility_feature=None, repository=None, collection=None, last_remediation_date=None, publication_date=None, sort_date=None, sort=None, search_after_id=None, search_after_value=None, size=None, _from=None, group=None):  # noqa: E501
    """Search for metadata records

    Search for metadata records against common fields. # noqa: E501

    :param q: The string passed in will be searched against title, creator, and publication identifiers such as ISBN and OCLC number.  If the q parameter is specified, the title, creator, publisher, and identifier parameters are ignored.
    :type q: str
    :param creator: The string passed in will be searched against creators.  These will most commonly be authors, but may also include editors and other contributors.
    :type creator: str
    :param title: The string passed in will be searched against result titles.
    :type title: str
    :param identifier: The string passed in will be searched against publication identifiers such as ISBN and OCLC number.
    :type identifier: str
    :param publisher: Search results will be limited to works with the given publisher. This currently does not work when combined with the q search parameter.
    :type publisher: str
    :param format: Search results will be limited to works with the given formats.
    :type format: list | bytes
    :param format_feature: Search results will be limited to works with the given format features.
    :type format_feature: dict | bytes
    :param format_version: Search results will be limited to works with the given format version.
    :type format_version: dict | bytes
    :param accessibility_feature: Search results will be limited to works with the given [accessibility features](https://www.w3.org/wiki/WebSchemas/Accessibility#Accessibility_terms_.28Version_2.0.29).
    :type accessibility_feature: dict | bytes
    :param repository: Search results will be limited to works in the given repository.
    :type repository: dict | bytes
    :param collection: Search results will be limited to works in the given repository collection.
    :type collection: dict | bytes
    :param last_remediation_date: Search results will be limited to works with a remediation date after the given date. Format is [ISO-8601](https://www.iso.org/iso-8601-date-and-time-format.html) date format (YYYY-MM-DD)
    :type last_remediation_date: dict | bytes
    :param publication_date: Search results will be limited to works with a publication date after the given date. Format is either a 4-digit year or the [ISO-8601](https://www.iso.org/iso-8601-date-and-time-format.html) date format (YYYY-MM-DD)
    :type publication_date: dict | bytes
    :param sort_date: Search results will be limited to works with a sort date after the given date. Format is [ISO-8601](https://www.iso.org/iso-8601-date-and-time-format.html) date format (YYYY-MM-DD) Sort date defaults to the same value as last remediation date.  If not available, it defaults to date accepted.  If date accepted is not available, it defaults to the date that the record was last updated in this index.  This field is never expected to be null.
    :type sort_date: dict | bytes
    :param sort: Results will be sorted in the given order, with title order ascending and date order descending.  Last remediation date is likely to be null; sort date is guaranteed not to be null.  When not specified, sort defaults to relevance.
    :type sort: str
    :param search_after_id: When paging through sorted results, return the next page of results that come after the record with this EMMA Record Identifier, i.e. the last emma_recordId in a previous page of results.  Must be paired with a searchAfterValue parameter.  When using the default relevance sort, use the \&quot;from\&quot; parameter instead for paging.
    :type search_after_id: dict | bytes
    :param search_after_value: When paging through sorted results, return the next page of results that come after the record with this URL encoded title or last remediation date, i.e. the last dc_title, dc_sortDate, emma_publicationDate, or emma_lastRemediationDate in a previous page of results. This value must match the type of the search sort.  Must be paired with a searchAfterId parameter. If a title value is truncated, the search engine will make its best effort to find the record for determining the page break. When using the default relevance sort, use the \&quot;from\&quot; parameter instead for paging.
    :type search_after_value: dict | bytes
    :param size: Number of results to return in the next page of results.   Defaults to 100.
    :type size: int
    :param _from: When using the default relevance result sort, use \&quot;from\&quot; to return the next page of results starting from the given result number.  If results are sorted, use searchAfterId and searchAfterValue instead. A limit of 1000 total results can be retrieved for the current query using the \&quot;from\&quot; parameter.
    :type _from: int
    :param group: [EXPERIMENTAL] Search results will be grouped by the given field.  Result page size will automatically be limited to 10 maximum.  Each result will have a number of grouped records provided as children, so the number of records returned will be more than 10.  Cannot be combined with sorting by title or date. 
    :type group: list | bytes

    :rtype: List[MetadataRecord]
    """
    if connexion.request.is_json:
        format = [Format.from_dict(d) for d in connexion.request.get_json()]  # noqa: E501
    if connexion.request.is_json:
        format_feature = FormatFeature.from_dict(connexion.request.get_json())  # noqa: E501
    if connexion.request.is_json:
        format_version = EmmaFormatVersion.from_dict(connexion.request.get_json())  # noqa: E501
    if connexion.request.is_json:
        accessibility_feature = AccessibilityFeature.from_dict(connexion.request.get_json())  # noqa: E501
    if connexion.request.is_json:
        repository = Repository.from_dict(connexion.request.get_json())  # noqa: E501
    if connexion.request.is_json:
        collection = Collection.from_dict(connexion.request.get_json())  # noqa: E501
    if connexion.request.is_json:
        last_remediation_date = LastRemediationDate.from_dict(connexion.request.get_json())  # noqa: E501
    if connexion.request.is_json:
        publication_date = PublicationDate.from_dict(connexion.request.get_json())  # noqa: E501
    if connexion.request.is_json:
        sort_date = SortDate.from_dict(connexion.request.get_json())  # noqa: E501
    if connexion.request.is_json:
        search_after_id = EmmaRecordIdentifier.from_dict(connexion.request.get_json())  # noqa: E501
    if connexion.request.is_json:
        search_after_value = SearchAfterValue.from_dict(connexion.request.get_json())  # noqa: E501
    if connexion.request.is_json:
        group = [Group.from_dict(d) for d in connexion.request.get_json()]  # noqa: E501
    return 'do some magic!'
