# SchemaOrgFields

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**s_accessibility_feature** | **list[str]** | List of accessibility features of this instance derived from the schema.org [Accessibility Feature specification](https://www.w3.org/wiki/WebSchemas/Accessibility#Accessibility_terms_.28Version_2.0.29). | [optional] 
**s_accessibility_control** | **list[str]** | List of accessibility controls of this instance derived from to the schema.org [Accessibility Control specification](https://www.w3.org/wiki/WebSchemas/Accessibility#Accessibility_terms_.28Version_2.0.29). | [optional] 
**s_accessibility_hazard** | **list[str]** | List of accessibility hazards of this instance as derived from to the schema.org [Accessibility Hazard specification](https://www.w3.org/wiki/WebSchemas/Accessibility#Accessibility_terms_.28Version_2.0.29). | [optional] 
**s_accessibility_api** | **list[str]** | List of accessibility APIs of this instance as derived from to the schema.org [Accessibility API specification](https://www.w3.org/wiki/WebSchemas/Accessibility#Accessibility_terms_.28Version_2.0.29). | [optional] 
**s_accessibility_summary** | **str** | Human-readable summary of accessibility features or deficiencies of this instance of the work as described in the schema.org [Accessibility Summary specification](https://www.w3.org/wiki/WebSchemas/Accessibility#Accessibility_terms_.28Version_2.0.29) | [optional] 
**s_access_mode** | **list[str]** | How the user can perceive this instance of the work as described in the schema.org [Access Mode specification](https://www.w3.org/wiki/WebSchemas/Accessibility#Accessibility_terms_.28Version_2.0.29). | [optional] 
**s_access_mode_sufficient** | **list[str]** | A list of single or combined access modes that are sufficient to understand all the intellectual content of a resource as described in the schema.org [Access Mode Sufficient specification](https://www.w3.org/wiki/WebSchemas/Accessibility#Accessibility_terms_.28Version_2.0.29) | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

