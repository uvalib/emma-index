# RemediationFields

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**rem_source** | **str** | The origin of the content on which the remediated file was based. | [optional] 
**rem_metadata_source** | **list[str]** | List of the origins of the metadata for the original creative work on which the remediated file was based. | [optional] 
**rem_remediated_by** | **list[str]** | List of the the origins of the remediated file, normally identifies the DSO. | [optional] 
**rem_complete** | **bool** | True if the submission is a presentation of the entire original work; false if the submission only covers certain sections or chapters, or contains gaps or omissions. | [optional] 
**rem_coverage** | **str** | For a submission which does not present the entire original work, describe the part(s) which are covered by the submission. | [optional] 
**rem_remediated_aspects** | **list[str]** | List of the remediations that are provided in this submission. | [optional] 
**rem_text_quality** | **str** | A measure of the quality of the original file on which the submission was based.   * &#x60;rawOcr&#x60; - Raw OCR; scanned with OCR but not otherwise processed   * &#x60;cleanedOcr&#x60; - Cleaned OCR   * &#x60;rekeyed&#x60; - Rekeyed   * &#x60;proofread&#x60; - Proofread   * &#x60;published&#x60; - Received in an electronic format from the publisher  | [optional] 
**rem_status** | **str** | The remediation status of submitted file. | [optional] 
**rem_remediation_date** | **date** | Date that this work was remediated.  This is an [ISO-8601](https://www.iso.org/iso-8601-date-and-time-format.html) format (YYYY-MM-DD) date. | [optional] 
**rem_comments** | **str** | Comments regarding the remediation on this work | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

