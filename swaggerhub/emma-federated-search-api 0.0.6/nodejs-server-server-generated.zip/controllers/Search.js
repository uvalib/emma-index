'use strict';

var utils = require('../utils/writer.js');
var Search = require('../service/SearchService');

module.exports.searchMetadata = function searchMetadata (req, res, next, q, creator, title, identifier, publisher, format, formatFeature, formatVersion, accessibilityFeature, repository, collection, lastRemediationDate, publicationDate, sortDate, sort, searchAfterId, searchAfterValue, size, from, group) {
  Search.searchMetadata(q, creator, title, identifier, publisher, format, formatFeature, formatVersion, accessibilityFeature, repository, collection, lastRemediationDate, publicationDate, sortDate, sort, searchAfterId, searchAfterValue, size, from, group)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
