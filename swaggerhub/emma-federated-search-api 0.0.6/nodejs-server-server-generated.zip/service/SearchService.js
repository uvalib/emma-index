'use strict';


/**
 * Search for metadata records
 * Search for metadata records against common fields.
 *
 * q String The string passed in will be searched against title, creator, and publication identifiers such as ISBN and OCLC number.  If the q parameter is specified, the title, creator, publisher, and identifier parameters are ignored. (optional)
 * creator String The string passed in will be searched against creators.  These will most commonly be authors, but may also include editors and other contributors. (optional)
 * title String The string passed in will be searched against result titles. (optional)
 * identifier String The string passed in will be searched against publication identifiers such as ISBN and OCLC number. (optional)
 * publisher String Search results will be limited to works with the given publisher. This currently does not work when combined with the q search parameter. (optional)
 * format List Search results will be limited to works with the given formats. (optional)
 * formatFeature formatFeature Search results will be limited to works with the given format features. (optional)
 * formatVersion EmmaFormatVersion Search results will be limited to works with the given format version. (optional)
 * accessibilityFeature accessibilityFeature Search results will be limited to works with the given [accessibility features](https://www.w3.org/wiki/WebSchemas/Accessibility#Accessibility_terms_.28Version_2.0.29). (optional)
 * repository repository Search results will be limited to works in the given repository. (optional)
 * collection collection Search results will be limited to works in the given repository collection. (optional)
 * lastRemediationDate lastRemediationDate Search results will be limited to works with a remediation date after the given date. Format is [ISO-8601](https://www.iso.org/iso-8601-date-and-time-format.html) date format (YYYY-MM-DD) (optional)
 * publicationDate publicationDate Search results will be limited to works with a publication date after the given date. Format is either a 4-digit year or the [ISO-8601](https://www.iso.org/iso-8601-date-and-time-format.html) date format (YYYY-MM-DD) (optional)
 * sortDate sortDate Search results will be limited to works with a sort date after the given date. Format is [ISO-8601](https://www.iso.org/iso-8601-date-and-time-format.html) date format (YYYY-MM-DD) Sort date defaults to the same value as last remediation date.  If not available, it defaults to date accepted.  If date accepted is not available, it defaults to the date that the record was last updated in this index.  This field is never expected to be null. (optional)
 * sort String Results will be sorted in the given order, with title order ascending and date order descending.  Last remediation date is likely to be null; sort date is guaranteed not to be null.  When not specified, sort defaults to relevance. (optional)
 * searchAfterId EmmaRecordIdentifier When paging through sorted results, return the next page of results that come after the record with this EMMA Record Identifier, i.e. the last emma_recordId in a previous page of results.  Must be paired with a searchAfterValue parameter.  When using the default relevance sort, use the \"from\" parameter instead for paging. (optional)
 * searchAfterValue searchAfterValue When paging through sorted results, return the next page of results that come after the record with this URL encoded title or last remediation date, i.e. the last dc_title, dc_sortDate, emma_publicationDate, or emma_lastRemediationDate in a previous page of results. This value must match the type of the search sort.  Must be paired with a searchAfterId parameter. If a title value is truncated, the search engine will make its best effort to find the record for determining the page break. When using the default relevance sort, use the \"from\" parameter instead for paging. (optional)
 * size Integer Number of results to return in the next page of results.   Defaults to 100. (optional)
 * from Integer When using the default relevance result sort, use \"from\" to return the next page of results starting from the given result number.  If results are sorted, use searchAfterId and searchAfterValue instead. A limit of 1000 total results can be retrieved for the current query using the \"from\" parameter. (optional)
 * group List [EXPERIMENTAL] Search results will be grouped by the given field.  Result page size will automatically be limited to 10 maximum.  Each result will have a number of grouped records provided as children, so the number of records returned will be more than 10.  Cannot be combined with sorting by title or date.  (optional)
 * returns List
 **/
exports.searchMetadata = function(q,creator,title,identifier,publisher,format,formatFeature,formatVersion,accessibilityFeature,repository,collection,lastRemediationDate,publicationDate,sortDate,sort,searchAfterId,searchAfterValue,size,from,group) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ "", "" ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

