# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.models.accessibility_feature import AccessibilityFeature  # noqa: E501
from swagger_server.models.collection import Collection  # noqa: E501
from swagger_server.models.emma_format_version import EmmaFormatVersion  # noqa: E501
from swagger_server.models.emma_record_identifier import EmmaRecordIdentifier  # noqa: E501
from swagger_server.models.format import Format  # noqa: E501
from swagger_server.models.format_feature import FormatFeature  # noqa: E501
from swagger_server.models.group import Group  # noqa: E501
from swagger_server.models.last_remediation_date import LastRemediationDate  # noqa: E501
from swagger_server.models.metadata_record import MetadataRecord  # noqa: E501
from swagger_server.models.publication_date import PublicationDate  # noqa: E501
from swagger_server.models.repository import Repository  # noqa: E501
from swagger_server.models.search_after_value import SearchAfterValue  # noqa: E501
from swagger_server.models.sort_date import SortDate  # noqa: E501
from swagger_server.test import BaseTestCase


class TestSearchController(BaseTestCase):
    """SearchController integration test stubs"""

    def test_search_metadata(self):
        """Test case for search_metadata

        Search for metadata records
        """
        query_string = [('q', 'q_example'),
                        ('creator', 'creator_example'),
                        ('title', 'title_example'),
                        ('identifier', 'identifier_example'),
                        ('publisher', 'publisher_example'),
                        ('format', Format()),
                        ('format_feature', FormatFeature()),
                        ('format_version', EmmaFormatVersion()),
                        ('accessibility_feature', AccessibilityFeature()),
                        ('repository', Repository()),
                        ('collection', Collection()),
                        ('last_remediation_date', LastRemediationDate()),
                        ('publication_date', PublicationDate()),
                        ('sort_date', SortDate()),
                        ('sort', 'sort_example'),
                        ('search_after_id', EmmaRecordIdentifier()),
                        ('search_after_value', SearchAfterValue()),
                        ('size', 56),
                        ('_from', 56),
                        ('group', Group())]
        response = self.client.open(
            '/search',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
