# MetadataRecord

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**dc_title** | **str** | The [title](https://www.dublincore.org/specifications/dublin-core/dcmi-terms/terms/title/) of the work.  Refers to either a non-periodical work such as a book or movie, or the title of a work within a periodical, such as an article or episode.  Examples:   - Book:      - &#x60;The Catcher in the Rye&#x60;      - A book   - Movie:      - &#x60;Jaws&#x60;      - A movie   - Journal Article:      - &#x60;A Review of Discourse Markers from the Functional Perspective&#x60;      - Title of a an article appearing in the _Journal of Arts and Humanities_   - Podcast Episode:      - &#x60;741: The Weight of Words&#x60;      - Title of an episode in the podcast _This American Life_  | [optional] 
**dc_creator** | **list[str]** | List of [creators](https://www.dublincore.org/specifications/dublin-core/dcmi-terms/terms/creator/) of the work | [optional] 
**dc_identifier** | [**list[PublicationIdentifier]**](PublicationIdentifier.md) | List of standard [identifier](https://www.dublincore.org/specifications/dublin-core/dcmi-terms/terms/identifier/) for a work.  In the case of | [optional] 
**dc_publisher** | **str** | The name of the [publisher](https://www.dublincore.org/specifications/dublin-core/dcmi-terms/terms/publisher/) | [optional] 
**dc_relation** | [**list[PublicationIdentifier]**](PublicationIdentifier.md) | List of standard [identifiers](https://www.dublincore.org/specifications/dublin-core/dcmi-terms/terms/relation/) for related works | [optional] 
**dc_language** | **list[str]** |  | [optional] 
**dc_rights** | **str** | Ownership-based [usage rights](https://www.dublincore.org/specifications/dublin-core/dcmi-terms/terms/rights/) on the work.  [See the Creative Commons site for descriptions of the specifics of different Creative Commons licenses.](https://creativecommons.org/about/cclicenses/) The generic &#x60;creativeCommons&#x60; value is [DEPRECATED]. | [optional] 
**dc_description** | **str** | [Description](https://www.dublincore.org/specifications/dublin-cor\\ e/dcmi-terms/terms/description/) of the work; typically a synopsis  | [optional] 
**dc_format** | [**DublinCoreFormat**](DublinCoreFormat.md) |  | [optional] 
**dc_type** | **str** | [DEPRECATED] [Type](https://www.dublincore.org/specifications/dublin-core/dcmi-\\ terms/terms/type/) of this instance of the work Use &#x60;emma_workType&#x60; instead.  | [optional] 
**dc_subject** | **list[str]** | List of [subjects](https://www.dublincore.org/specifications/dublin-core/dcmi-terms/terms/subject/) describing the work. | [optional] 
**dcterms_date_accepted** | **date** | [Date](https://www.dublincore.org/specifications/dublin-core/dcmi-terms/terms/dateAccepted/) that the work was accepted into the repository, using [ISO-8601](https://www.iso.org/iso-8601-date-and-time-format.html) format (YYYY-MM-DD) | [optional] 
**dcterms_date_copyright** | **str** | [DEPRECATED] The 4-digit year that the work was copyrighted Use &#x60;emma_publicationDate&#x60; instead.  | [optional] 
**periodical** | **bool** | True if we should treat this work like an article, issue, or episode of a periodical; False or absent otherwise.  | [optional] 
**s_accessibility_feature** | **list[str]** | List of accessibility features of this instance derived from the schema.org [Accessibility Feature specification](https://www.w3.org/wiki/WebSchemas/Accessibility#Accessibility_terms_.28Version_2.0.29). | [optional] 
**s_accessibility_control** | **list[str]** | List of accessibility controls of this instance derived from to the schema.org [Accessibility Control specification](https://www.w3.org/wiki/WebSchemas/Accessibility#Accessibility_terms_.28Version_2.0.29). | [optional] 
**s_accessibility_hazard** | **list[str]** | List of accessibility hazards of this instance as derived from to the schema.org [Accessibility Hazard specification](https://www.w3.org/wiki/WebSchemas/Accessibility#Accessibility_terms_.28Version_2.0.29). | [optional] 
**s_accessibility_api** | **list[str]** | List of accessibility APIs of this instance as derived from to the schema.org [Accessibility API specification](https://www.w3.org/wiki/WebSchemas/Accessibility#Accessibility_terms_.28Version_2.0.29). | [optional] 
**s_accessibility_summary** | **str** | Human-readable summary of accessibility features or deficiencies of this instance of the work as described in the schema.org [Accessibility Summary specification](https://www.w3.org/wiki/WebSchemas/Accessibility#Accessibility_terms_.28Version_2.0.29) | [optional] 
**s_access_mode** | **list[str]** | How the user can perceive this instance of the work as described in the schema.org [Access Mode specification](https://www.w3.org/wiki/WebSchemas/Accessibility#Accessibility_terms_.28Version_2.0.29). | [optional] 
**s_access_mode_sufficient** | **list[str]** | A list of single or combined access modes that are sufficient to understand all the intellectual content of a resource as described in the schema.org [Access Mode Sufficient specification](https://www.w3.org/wiki/WebSchemas/Accessibility#Accessibility_terms_.28Version_2.0.29) | [optional] 
**rem_source** | **str** | The origin of the content on which the remediated file was based. | [optional] 
**rem_metadata_source** | **list[str]** | List of the origins of the metadata for the original creative work on which the remediated file was based. | [optional] 
**rem_remediated_by** | **list[str]** | List of the the origins of the remediated file, normally identifies the DSO. | [optional] 
**rem_complete** | **bool** | True if the submission is a presentation of the entire original work; false if the submission only covers certain sections or chapters, or contains gaps or omissions. | [optional] 
**rem_coverage** | **str** | For a submission which does not present the entire original work, describe the part(s) which are covered by the submission. | [optional] 
**rem_remediated_aspects** | **list[str]** | List of the remediations that are provided in this submission. | [optional] 
**rem_text_quality** | **str** | A measure of the quality of the original file on which the submission was based.   * &#x60;rawOcr&#x60; - Raw OCR; scanned with OCR but not otherwise processed   * &#x60;cleanedOcr&#x60; - Cleaned OCR   * &#x60;rekeyed&#x60; - Rekeyed   * &#x60;proofread&#x60; - Proofread   * &#x60;published&#x60; - Received in an electronic format from the publisher  | [optional] 
**rem_status** | **str** | The remediation status of submitted file. | [optional] 
**rem_remediation_date** | **date** | Date that this work was remediated.  This is an [ISO-8601](https://www.iso.org/iso-8601-date-and-time-format.html) format (YYYY-MM-DD) date. | [optional] 
**rem_comments** | **str** | Comments regarding the remediation on this work | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

