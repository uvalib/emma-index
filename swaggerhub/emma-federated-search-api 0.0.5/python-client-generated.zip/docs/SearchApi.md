# swagger_client.SearchApi

All URIs are relative to *https://api.staging.bookshareunifiedsearch.org*

Method | HTTP request | Description
------------- | ------------- | -------------
[**search_metadata**](SearchApi.md#search_metadata) | **GET** /search | Search for metadata records

# **search_metadata**
> list[MetadataRecord] search_metadata(q=q, creator=creator, title=title, identifier=identifier, publisher=publisher, format=format, format_feature=format_feature, format_version=format_version, accessibility_feature=accessibility_feature, repository=repository, collection=collection, last_remediation_date=last_remediation_date, publication_date=publication_date, sort_date=sort_date, sort=sort, search_after_id=search_after_id, search_after_value=search_after_value, size=size, _from=_from, group=group)

Search for metadata records

Search for metadata records against common fields.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.SearchApi()
q = 'q_example' # str | The string passed in will be searched against title, creator, and publication identifiers such as ISBN and OCLC number.  If the q parameter is specified, the title, creator, publisher, and identifier parameters are ignored. (optional)
creator = 'creator_example' # str | The string passed in will be searched against creators.  These will most commonly be authors, but may also include editors and other contributors. (optional)
title = 'title_example' # str | The string passed in will be searched against result titles. (optional)
identifier = 'identifier_example' # str | The string passed in will be searched against publication identifiers such as ISBN and OCLC number. (optional)
publisher = 'publisher_example' # str | Search results will be limited to works with the given publisher. This currently does not work when combined with the q search parameter. (optional)
format = [swagger_client.Format()] # list[Format] | Search results will be limited to works with the given formats. (optional)
format_feature = swagger_client.FormatFeature() # FormatFeature | Search results will be limited to works with the given format features. (optional)
format_version = swagger_client.EmmaFormatVersion() # EmmaFormatVersion | Search results will be limited to works with the given format version. (optional)
accessibility_feature = swagger_client.AccessibilityFeature() # AccessibilityFeature | Search results will be limited to works with the given [accessibility features](https://www.w3.org/wiki/WebSchemas/Accessibility#Accessibility_terms_.28Version_2.0.29). (optional)
repository = swagger_client.Repository() # Repository | Search results will be limited to works in the given repository. (optional)
collection = swagger_client.Collection() # Collection | Search results will be limited to works in the given repository collection. (optional)
last_remediation_date = swagger_client.LastRemediationDate() # LastRemediationDate | Search results will be limited to works with a remediation date after the given date. Format is [ISO-8601](https://www.iso.org/iso-8601-date-and-time-format.html) date format (YYYY-MM-DD) (optional)
publication_date = swagger_client.PublicationDate() # PublicationDate | Search results will be limited to works with a publication date after the given date. Format is either a 4-digit year or the [ISO-8601](https://www.iso.org/iso-8601-date-and-time-format.html) date format (YYYY-MM-DD) (optional)
sort_date = swagger_client.SortDate() # SortDate | Search results will be limited to works with a sort date after the given date. Format is [ISO-8601](https://www.iso.org/iso-8601-date-and-time-format.html) date format (YYYY-MM-DD) Sort date defaults to the same value as last remediation date.  If not available, it defaults to date accepted.  If date accepted is not available, it defaults to the date that the record was last updated in this index.  This field is never expected to be null. (optional)
sort = 'sort_example' # str | Results will be sorted in the given order, with title order ascending and date order descending.  Last remediation date is likely to be null; sort date is guaranteed not to be null.  When not specified, sort defaults to relevance. (optional)
search_after_id = swagger_client.EmmaRecordIdentifier() # EmmaRecordIdentifier | When paging through sorted results, return the next page of results that come after the record with this EMMA Record Identifier, i.e. the last emma_recordId in a previous page of results.  Must be paired with a searchAfterValue parameter.  When using the default relevance sort, use the \"from\" parameter instead for paging. (optional)
search_after_value = swagger_client.SearchAfterValue() # SearchAfterValue | When paging through sorted results, return the next page of results that come after the record with this URL encoded title or last remediation date, i.e. the last dc_title, dc_sortDate, emma_publicationDate, or emma_lastRemediationDate in a previous page of results. This value must match the type of the search sort.  Must be paired with a searchAfterId parameter. If a title value is truncated, the search engine will make its best effort to find the record for determining the page break. When using the default relevance sort, use the \"from\" parameter instead for paging. (optional)
size = 56 # int | Number of results to return in the next page of results.   Defaults to 100. (optional)
_from = 56 # int | When using the default relevance result sort, use \"from\" to return the next page of results starting from the given result number.  If results are sorted, use searchAfterId and searchAfterValue instead. A limit of 1000 total results can be retrieved for the current query using the \"from\" parameter. (optional)
group = [swagger_client.Group()] # list[Group] | [EXPERIMENTAL] Search results will be grouped by the given field.  Result page size will automatically be limited to 10 maximum.  Each result will have a number of grouped records provided as children, so the number of records returned will be more than 10.  Cannot be combined with sorting by title or date.  (optional)

try:
    # Search for metadata records
    api_response = api_instance.search_metadata(q=q, creator=creator, title=title, identifier=identifier, publisher=publisher, format=format, format_feature=format_feature, format_version=format_version, accessibility_feature=accessibility_feature, repository=repository, collection=collection, last_remediation_date=last_remediation_date, publication_date=publication_date, sort_date=sort_date, sort=sort, search_after_id=search_after_id, search_after_value=search_after_value, size=size, _from=_from, group=group)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SearchApi->search_metadata: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **q** | **str**| The string passed in will be searched against title, creator, and publication identifiers such as ISBN and OCLC number.  If the q parameter is specified, the title, creator, publisher, and identifier parameters are ignored. | [optional] 
 **creator** | **str**| The string passed in will be searched against creators.  These will most commonly be authors, but may also include editors and other contributors. | [optional] 
 **title** | **str**| The string passed in will be searched against result titles. | [optional] 
 **identifier** | **str**| The string passed in will be searched against publication identifiers such as ISBN and OCLC number. | [optional] 
 **publisher** | **str**| Search results will be limited to works with the given publisher. This currently does not work when combined with the q search parameter. | [optional] 
 **format** | [**list[Format]**](Format.md)| Search results will be limited to works with the given formats. | [optional] 
 **format_feature** | [**FormatFeature**](.md)| Search results will be limited to works with the given format features. | [optional] 
 **format_version** | [**EmmaFormatVersion**](.md)| Search results will be limited to works with the given format version. | [optional] 
 **accessibility_feature** | [**AccessibilityFeature**](.md)| Search results will be limited to works with the given [accessibility features](https://www.w3.org/wiki/WebSchemas/Accessibility#Accessibility_terms_.28Version_2.0.29). | [optional] 
 **repository** | [**Repository**](.md)| Search results will be limited to works in the given repository. | [optional] 
 **collection** | [**Collection**](.md)| Search results will be limited to works in the given repository collection. | [optional] 
 **last_remediation_date** | [**LastRemediationDate**](.md)| Search results will be limited to works with a remediation date after the given date. Format is [ISO-8601](https://www.iso.org/iso-8601-date-and-time-format.html) date format (YYYY-MM-DD) | [optional] 
 **publication_date** | [**PublicationDate**](.md)| Search results will be limited to works with a publication date after the given date. Format is either a 4-digit year or the [ISO-8601](https://www.iso.org/iso-8601-date-and-time-format.html) date format (YYYY-MM-DD) | [optional] 
 **sort_date** | [**SortDate**](.md)| Search results will be limited to works with a sort date after the given date. Format is [ISO-8601](https://www.iso.org/iso-8601-date-and-time-format.html) date format (YYYY-MM-DD) Sort date defaults to the same value as last remediation date.  If not available, it defaults to date accepted.  If date accepted is not available, it defaults to the date that the record was last updated in this index.  This field is never expected to be null. | [optional] 
 **sort** | **str**| Results will be sorted in the given order, with title order ascending and date order descending.  Last remediation date is likely to be null; sort date is guaranteed not to be null.  When not specified, sort defaults to relevance. | [optional] 
 **search_after_id** | [**EmmaRecordIdentifier**](.md)| When paging through sorted results, return the next page of results that come after the record with this EMMA Record Identifier, i.e. the last emma_recordId in a previous page of results.  Must be paired with a searchAfterValue parameter.  When using the default relevance sort, use the \&quot;from\&quot; parameter instead for paging. | [optional] 
 **search_after_value** | [**SearchAfterValue**](.md)| When paging through sorted results, return the next page of results that come after the record with this URL encoded title or last remediation date, i.e. the last dc_title, dc_sortDate, emma_publicationDate, or emma_lastRemediationDate in a previous page of results. This value must match the type of the search sort.  Must be paired with a searchAfterId parameter. If a title value is truncated, the search engine will make its best effort to find the record for determining the page break. When using the default relevance sort, use the \&quot;from\&quot; parameter instead for paging. | [optional] 
 **size** | **int**| Number of results to return in the next page of results.   Defaults to 100. | [optional] 
 **_from** | **int**| When using the default relevance result sort, use \&quot;from\&quot; to return the next page of results starting from the given result number.  If results are sorted, use searchAfterId and searchAfterValue instead. A limit of 1000 total results can be retrieved for the current query using the \&quot;from\&quot; parameter. | [optional] 
 **group** | [**list[Group]**](Group.md)| [EXPERIMENTAL] Search results will be grouped by the given field.  Result page size will automatically be limited to 10 maximum.  Each result will have a number of grouped records provided as children, so the number of records returned will be more than 10.  Cannot be combined with sorting by title or date.  | [optional] 

### Return type

[**list[MetadataRecord]**](MetadataRecord.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

