# EmmaFederatedSearchApi.DublinCoreFields

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**dcTitle** | **String** | The [title](https://www.dublincore.org/specifications/dublin-core/dcmi-terms/terms/title/) of the work.  Refers to either a non-periodical work such as a book or movie, or the title of a work within a periodical, such as an article or episode.  Examples:   - Book:      - &#x60;The Catcher in the Rye&#x60;      - A book   - Movie:      - &#x60;Jaws&#x60;      - A movie   - Journal Article:      - &#x60;A Review of Discourse Markers from the Functional Perspective&#x60;      - Title of a an article appearing in the _Journal of Arts and Humanities_   - Podcast Episode:      - &#x60;741: The Weight of Words&#x60;      - Title of an episode in the podcast _This American Life_  | [optional] 
**dcCreator** | **[String]** | List of [creators](https://www.dublincore.org/specifications/dublin-core/dcmi-terms/terms/creator/) of the work | [optional] 
**dcIdentifier** | [**[PublicationIdentifier]**](PublicationIdentifier.md) | List of standard [identifier](https://www.dublincore.org/specifications/dublin-core/dcmi-terms/terms/identifier/) for a work.  In the case of | [optional] 
**dcPublisher** | **String** | The name of the [publisher](https://www.dublincore.org/specifications/dublin-core/dcmi-terms/terms/publisher/) | [optional] 
**dcRelation** | [**[PublicationIdentifier]**](PublicationIdentifier.md) | List of standard [identifiers](https://www.dublincore.org/specifications/dublin-core/dcmi-terms/terms/relation/) for related works | [optional] 
**dcLanguage** | **[String]** |  | [optional] 
**dcRights** | **String** | Ownership-based [usage rights](https://www.dublincore.org/specifications/dublin-core/dcmi-terms/terms/rights/) on the work.  [See the Creative Commons site for descriptions of the specifics of different Creative Commons licenses.](https://creativecommons.org/about/cclicenses/) The generic &#x60;creativeCommons&#x60; value is [DEPRECATED]. | [optional] 
**dcDescription** | **String** | [Description](https://www.dublincore.org/specifications/dublin-cor\\ e/dcmi-terms/terms/description/) of the work; typically a synopsis  | [optional] 
**dcFormat** | [**DublinCoreFormat**](DublinCoreFormat.md) |  | [optional] 
**dcType** | **String** | [DEPRECATED] [Type](https://www.dublincore.org/specifications/dublin-core/dcmi-\\ terms/terms/type/) of this instance of the work Use &#x60;emma_workType&#x60; instead.  | [optional] 
**dcSubject** | **[String]** | List of [subjects](https://www.dublincore.org/specifications/dublin-core/dcmi-terms/terms/subject/) describing the work. | [optional] 
**dctermsDateAccepted** | **Date** | [Date](https://www.dublincore.org/specifications/dublin-core/dcmi-terms/terms/dateAccepted/) that the work was accepted into the repository, using [ISO-8601](https://www.iso.org/iso-8601-date-and-time-format.html) format (YYYY-MM-DD) | [optional] 
**dctermsDateCopyright** | **String** | [DEPRECATED] The 4-digit year that the work was copyrighted Use &#x60;emma_publicationDate&#x60; instead.  | [optional] 

<a name="DcRightsEnum"></a>
## Enum: DcRightsEnum

* `publicDomain` (value: `"publicDomain"`)
* `creativeCommons` (value: `"creativeCommons"`)
* `ccBy` (value: `"ccBy"`)
* `ccBySa` (value: `"ccBySa"`)
* `ccByNa` (value: `"ccByNa"`)
* `ccByNcSa` (value: `"ccByNcSa"`)
* `ccByNd` (value: `"ccByNd"`)
* `cc0` (value: `"cc0"`)
* `copyright` (value: `"copyright"`)
* `embargo` (value: `"embargo"`)
* `license` (value: `"license"`)
* `other` (value: `"other"`)


<a name="DcTypeEnum"></a>
## Enum: DcTypeEnum

* `text` (value: `"text"`)
* `sound` (value: `"sound"`)
* `collection` (value: `"collection"`)
* `dataset` (value: `"dataset"`)
* `event` (value: `"event"`)
* `image` (value: `"image"`)
* `interactiveResource` (value: `"interactiveResource"`)
* `service` (value: `"service"`)
* `physicalObject` (value: `"physicalObject"`)
* `stillImage` (value: `"stillImage"`)
* `movingImage` (value: `"movingImage"`)

