# EmmaFederatedSearchApi.EmmaLastRemediationDate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
