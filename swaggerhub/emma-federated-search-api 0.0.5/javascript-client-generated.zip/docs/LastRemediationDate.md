# EmmaFederatedSearchApi.LastRemediationDate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
