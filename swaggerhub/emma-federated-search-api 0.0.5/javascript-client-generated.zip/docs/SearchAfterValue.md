# EmmaFederatedSearchApi.SearchAfterValue

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
