# EmmaFederatedSearchApi.Group

## Enum

* `titleId` (value: `"emma_titleId"`)
* `repositoryRecordId` (value: `"emma_repositoryRecordId"`)
