# EmmaFederatedSearchApi.SchemaOrgFields

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sAccessibilityFeature** | **[String]** | List of accessibility features of this instance derived from the schema.org [Accessibility Feature specification](https://www.w3.org/wiki/WebSchemas/Accessibility#Accessibility_terms_.28Version_2.0.29). | [optional] 
**sAccessibilityControl** | **[String]** | List of accessibility controls of this instance derived from to the schema.org [Accessibility Control specification](https://www.w3.org/wiki/WebSchemas/Accessibility#Accessibility_terms_.28Version_2.0.29). | [optional] 
**sAccessibilityHazard** | **[String]** | List of accessibility hazards of this instance as derived from to the schema.org [Accessibility Hazard specification](https://www.w3.org/wiki/WebSchemas/Accessibility#Accessibility_terms_.28Version_2.0.29). | [optional] 
**sAccessibilityAPI** | **[String]** | List of accessibility APIs of this instance as derived from to the schema.org [Accessibility API specification](https://www.w3.org/wiki/WebSchemas/Accessibility#Accessibility_terms_.28Version_2.0.29). | [optional] 
**sAccessibilitySummary** | **String** | Human-readable summary of accessibility features or deficiencies of this instance of the work as described in the schema.org [Accessibility Summary specification](https://www.w3.org/wiki/WebSchemas/Accessibility#Accessibility_terms_.28Version_2.0.29) | [optional] 
**sAccessMode** | **[String]** | How the user can perceive this instance of the work as described in the schema.org [Access Mode specification](https://www.w3.org/wiki/WebSchemas/Accessibility#Accessibility_terms_.28Version_2.0.29). | [optional] 
**sAccessModeSufficient** | **[String]** | A list of single or combined access modes that are sufficient to understand all the intellectual content of a resource as described in the schema.org [Access Mode Sufficient specification](https://www.w3.org/wiki/WebSchemas/Accessibility#Accessibility_terms_.28Version_2.0.29) | [optional] 

<a name="[SAccessibilityFeatureEnum]"></a>
## Enum: [SAccessibilityFeatureEnum]

* `alternativeText` (value: `"alternativeText"`)
* `annotations` (value: `"annotations"`)
* `audioDescription` (value: `"audioDescription"`)
* `bookmarks` (value: `"bookmarks"`)
* `braille` (value: `"braille"`)
* `captions` (value: `"captions"`)
* `chemML` (value: `"ChemML"`)
* `describedMath` (value: `"describedMath"`)
* `displayTransformability` (value: `"displayTransformability"`)
* `displayTransformabilitybackgroundColor` (value: `"displayTransformability/background-color"`)
* `displayTransformabilitycolor` (value: `"displayTransformability/color"`)
* `displayTransformabilityfontHeight` (value: `"displayTransformability/font-height"`)
* `displayTransformabilityfontSize` (value: `"displayTransformability/font-size"`)
* `displayTransformabilitylineHeight` (value: `"displayTransformability/line-height"`)
* `displayTransformabilitywordSpacing` (value: `"displayTransformability/word-spacing"`)
* `highContrastAudio` (value: `"highContrastAudio"`)
* `highContrastDisplay` (value: `"highContrastDisplay"`)
* `index` (value: `"index"`)
* `largePrint` (value: `"largePrint"`)
* `latex` (value: `"latex"`)
* `longDescription` (value: `"longDescription"`)
* `mathML` (value: `"MathML"`)
* `physicalObject` (value: `"physicalObject"`)
* `printPageNumbers` (value: `"printPageNumbers"`)
* `readingOrder` (value: `"readingOrder"`)
* `rubyAnnotations` (value: `"rubyAnnotations"`)
* `signLanguage` (value: `"signLanguage"`)
* `sound` (value: `"sound"`)
* `stillImage` (value: `"stillImage"`)
* `structuralNavigation` (value: `"structuralNavigation"`)
* `synchronizedAudioText` (value: `"synchronizedAudioText"`)
* `tableOfContents` (value: `"tableOfContents"`)
* `tactileGraphic` (value: `"tactileGraphic"`)
* `tactileObject` (value: `"tactileObject"`)
* `taggedPDF` (value: `"taggedPDF"`)
* `timingControl` (value: `"timingControl"`)
* `transcript` (value: `"transcript"`)
* `ttsMarkup` (value: `"ttsMarkup"`)
* `unlocked` (value: `"unlocked"`)


<a name="[SAccessibilityControlEnum]"></a>
## Enum: [SAccessibilityControlEnum]

* `fullAudioControl` (value: `"fullAudioControl"`)
* `fullKeyboardControl` (value: `"fullKeyboardControl"`)
* `fullMouseControl` (value: `"fullMouseControl"`)
* `fullTouchControl` (value: `"fullTouchControl"`)
* `fullVideoControl` (value: `"fullVideoControl"`)
* `fullSwitchControl` (value: `"fullSwitchControl"`)
* `fullVoiceControl` (value: `"fullVoiceControl"`)


<a name="[SAccessibilityHazardEnum]"></a>
## Enum: [SAccessibilityHazardEnum]

* `flashing` (value: `"flashing"`)
* `noFlashingHazard` (value: `"noFlashingHazard"`)
* `motionSimulation` (value: `"motionSimulation"`)
* `noMotionSimulationHazard` (value: `"noMotionSimulationHazard"`)
* `sound` (value: `"sound"`)
* `noSoundHazard` (value: `"noSoundHazard"`)


<a name="[SAccessibilityAPIEnum]"></a>
## Enum: [SAccessibilityAPIEnum]

* `ARIA` (value: `"ARIA"`)


<a name="[SAccessModeEnum]"></a>
## Enum: [SAccessModeEnum]

* `auditory` (value: `"auditory"`)
* `chartOnVisual` (value: `"chartOnVisual"`)
* `chemOnVisual` (value: `"chemOnVisual"`)
* `colorDependent` (value: `"colorDependent"`)
* `diagramOnVisual` (value: `"diagramOnVisual"`)
* `mathOnVisual` (value: `"mathOnVisual"`)
* `musicOnVisual` (value: `"musicOnVisual"`)
* `tactile` (value: `"tactile"`)
* `textOnVisual` (value: `"textOnVisual"`)
* `textual` (value: `"textual"`)
* `visual` (value: `"visual"`)


<a name="[SAccessModeSufficientEnum]"></a>
## Enum: [SAccessModeSufficientEnum]

* `auditory` (value: `"auditory"`)
* `tactile` (value: `"tactile"`)
* `textual` (value: `"textual"`)
* `visual` (value: `"visual"`)

