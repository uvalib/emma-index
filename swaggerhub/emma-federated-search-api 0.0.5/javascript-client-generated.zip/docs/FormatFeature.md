# EmmaFederatedSearchApi.FormatFeature

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
