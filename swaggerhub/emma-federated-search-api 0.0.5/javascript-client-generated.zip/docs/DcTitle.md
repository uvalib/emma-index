# EmmaFederatedSearchApi.DcTitle

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
