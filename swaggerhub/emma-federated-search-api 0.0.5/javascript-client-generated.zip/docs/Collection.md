# EmmaFederatedSearchApi.Collection

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
