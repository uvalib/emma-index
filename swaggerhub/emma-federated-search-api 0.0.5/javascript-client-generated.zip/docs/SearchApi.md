# EmmaFederatedSearchApi.SearchApi

All URIs are relative to *https://api.staging.bookshareunifiedsearch.org*

Method | HTTP request | Description
------------- | ------------- | -------------
[**searchMetadata**](SearchApi.md#searchMetadata) | **GET** /search | Search for metadata records

<a name="searchMetadata"></a>
# **searchMetadata**
> [MetadataRecord] searchMetadata(opts)

Search for metadata records

Search for metadata records against common fields.

### Example
```javascript
import {EmmaFederatedSearchApi} from 'emma_federated_search_api';

let apiInstance = new EmmaFederatedSearchApi.SearchApi();
let opts = { 
  'q': "q_example", // String | The string passed in will be searched against title, creator, and publication identifiers such as ISBN and OCLC number.  If the q parameter is specified, the title, creator, publisher, and identifier parameters are ignored.
  'creator': "creator_example", // String | The string passed in will be searched against creators.  These will most commonly be authors, but may also include editors and other contributors.
  'title': "title_example", // String | The string passed in will be searched against result titles.
  'identifier': "identifier_example", // String | The string passed in will be searched against publication identifiers such as ISBN and OCLC number.
  'publisher': "publisher_example", // String | Search results will be limited to works with the given publisher. This currently does not work when combined with the q search parameter.
  'format': [new EmmaFederatedSearchApi.Format()], // [Format] | Search results will be limited to works with the given formats.
  'formatFeature': new EmmaFederatedSearchApi.FormatFeature(), // FormatFeature | Search results will be limited to works with the given format features.
  'formatVersion': new EmmaFederatedSearchApi.EmmaFormatVersion(), // EmmaFormatVersion | Search results will be limited to works with the given format version.
  'accessibilityFeature': new EmmaFederatedSearchApi.AccessibilityFeature(), // AccessibilityFeature | Search results will be limited to works with the given [accessibility features](https://www.w3.org/wiki/WebSchemas/Accessibility#Accessibility_terms_.28Version_2.0.29).
  'repository': new EmmaFederatedSearchApi.Repository(), // Repository | Search results will be limited to works in the given repository.
  'collection': new EmmaFederatedSearchApi.Collection(), // Collection | Search results will be limited to works in the given repository collection.
  'lastRemediationDate': new EmmaFederatedSearchApi.LastRemediationDate(), // LastRemediationDate | Search results will be limited to works with a remediation date after the given date. Format is [ISO-8601](https://www.iso.org/iso-8601-date-and-time-format.html) date format (YYYY-MM-DD)
  'publicationDate': new EmmaFederatedSearchApi.PublicationDate(), // PublicationDate | Search results will be limited to works with a publication date after the given date. Format is either a 4-digit year or the [ISO-8601](https://www.iso.org/iso-8601-date-and-time-format.html) date format (YYYY-MM-DD)
  'sortDate': new EmmaFederatedSearchApi.SortDate(), // SortDate | Search results will be limited to works with a sort date after the given date. Format is [ISO-8601](https://www.iso.org/iso-8601-date-and-time-format.html) date format (YYYY-MM-DD) Sort date defaults to the same value as last remediation date.  If not available, it defaults to date accepted.  If date accepted is not available, it defaults to the date that the record was last updated in this index.  This field is never expected to be null.
  'sort': "sort_example", // String | Results will be sorted in the given order, with title order ascending and date order descending.  Last remediation date is likely to be null; sort date is guaranteed not to be null.  When not specified, sort defaults to relevance.
  'searchAfterId': new EmmaFederatedSearchApi.EmmaRecordIdentifier(), // EmmaRecordIdentifier | When paging through sorted results, return the next page of results that come after the record with this EMMA Record Identifier, i.e. the last emma_recordId in a previous page of results.  Must be paired with a searchAfterValue parameter.  When using the default relevance sort, use the \"from\" parameter instead for paging.
  'searchAfterValue': new EmmaFederatedSearchApi.SearchAfterValue(), // SearchAfterValue | When paging through sorted results, return the next page of results that come after the record with this URL encoded title or last remediation date, i.e. the last dc_title, dc_sortDate, emma_publicationDate, or emma_lastRemediationDate in a previous page of results. This value must match the type of the search sort.  Must be paired with a searchAfterId parameter. If a title value is truncated, the search engine will make its best effort to find the record for determining the page break. When using the default relevance sort, use the \"from\" parameter instead for paging.
  'size': 56, // Number | Number of results to return in the next page of results.   Defaults to 100.
  'from': 56, // Number | When using the default relevance result sort, use \"from\" to return the next page of results starting from the given result number.  If results are sorted, use searchAfterId and searchAfterValue instead. A limit of 1000 total results can be retrieved for the current query using the \"from\" parameter.
  'group': [new EmmaFederatedSearchApi.Group()] // [Group] | [EXPERIMENTAL] Search results will be grouped by the given field.  Result page size will automatically be limited to 10 maximum.  Each result will have a number of grouped records provided as children, so the number of records returned will be more than 10.  Cannot be combined with sorting by title or date. 
};
apiInstance.searchMetadata(opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **q** | **String**| The string passed in will be searched against title, creator, and publication identifiers such as ISBN and OCLC number.  If the q parameter is specified, the title, creator, publisher, and identifier parameters are ignored. | [optional] 
 **creator** | **String**| The string passed in will be searched against creators.  These will most commonly be authors, but may also include editors and other contributors. | [optional] 
 **title** | **String**| The string passed in will be searched against result titles. | [optional] 
 **identifier** | **String**| The string passed in will be searched against publication identifiers such as ISBN and OCLC number. | [optional] 
 **publisher** | **String**| Search results will be limited to works with the given publisher. This currently does not work when combined with the q search parameter. | [optional] 
 **format** | [**[Format]**](Format.md)| Search results will be limited to works with the given formats. | [optional] 
 **formatFeature** | [**FormatFeature**](.md)| Search results will be limited to works with the given format features. | [optional] 
 **formatVersion** | [**EmmaFormatVersion**](.md)| Search results will be limited to works with the given format version. | [optional] 
 **accessibilityFeature** | [**AccessibilityFeature**](.md)| Search results will be limited to works with the given [accessibility features](https://www.w3.org/wiki/WebSchemas/Accessibility#Accessibility_terms_.28Version_2.0.29). | [optional] 
 **repository** | [**Repository**](.md)| Search results will be limited to works in the given repository. | [optional] 
 **collection** | [**Collection**](.md)| Search results will be limited to works in the given repository collection. | [optional] 
 **lastRemediationDate** | [**LastRemediationDate**](.md)| Search results will be limited to works with a remediation date after the given date. Format is [ISO-8601](https://www.iso.org/iso-8601-date-and-time-format.html) date format (YYYY-MM-DD) | [optional] 
 **publicationDate** | [**PublicationDate**](.md)| Search results will be limited to works with a publication date after the given date. Format is either a 4-digit year or the [ISO-8601](https://www.iso.org/iso-8601-date-and-time-format.html) date format (YYYY-MM-DD) | [optional] 
 **sortDate** | [**SortDate**](.md)| Search results will be limited to works with a sort date after the given date. Format is [ISO-8601](https://www.iso.org/iso-8601-date-and-time-format.html) date format (YYYY-MM-DD) Sort date defaults to the same value as last remediation date.  If not available, it defaults to date accepted.  If date accepted is not available, it defaults to the date that the record was last updated in this index.  This field is never expected to be null. | [optional] 
 **sort** | **String**| Results will be sorted in the given order, with title order ascending and date order descending.  Last remediation date is likely to be null; sort date is guaranteed not to be null.  When not specified, sort defaults to relevance. | [optional] 
 **searchAfterId** | [**EmmaRecordIdentifier**](.md)| When paging through sorted results, return the next page of results that come after the record with this EMMA Record Identifier, i.e. the last emma_recordId in a previous page of results.  Must be paired with a searchAfterValue parameter.  When using the default relevance sort, use the \&quot;from\&quot; parameter instead for paging. | [optional] 
 **searchAfterValue** | [**SearchAfterValue**](.md)| When paging through sorted results, return the next page of results that come after the record with this URL encoded title or last remediation date, i.e. the last dc_title, dc_sortDate, emma_publicationDate, or emma_lastRemediationDate in a previous page of results. This value must match the type of the search sort.  Must be paired with a searchAfterId parameter. If a title value is truncated, the search engine will make its best effort to find the record for determining the page break. When using the default relevance sort, use the \&quot;from\&quot; parameter instead for paging. | [optional] 
 **size** | **Number**| Number of results to return in the next page of results.   Defaults to 100. | [optional] 
 **from** | **Number**| When using the default relevance result sort, use \&quot;from\&quot; to return the next page of results starting from the given result number.  If results are sorted, use searchAfterId and searchAfterValue instead. A limit of 1000 total results can be retrieved for the current query using the \&quot;from\&quot; parameter. | [optional] 
 **group** | [**[Group]**](Group.md)| [EXPERIMENTAL] Search results will be grouped by the given field.  Result page size will automatically be limited to 10 maximum.  Each result will have a number of grouped records provided as children, so the number of records returned will be more than 10.  Cannot be combined with sorting by title or date.  | [optional] 

### Return type

[**[MetadataRecord]**](MetadataRecord.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

