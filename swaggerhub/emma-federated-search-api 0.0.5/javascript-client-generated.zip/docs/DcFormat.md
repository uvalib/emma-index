# EmmaFederatedSearchApi.DcFormat

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
