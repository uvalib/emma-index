# EmmaFederatedSearchApi.PeriodicalIdentifier

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
